# GPOC Staff Portal (Static HTML/CSS)

## Run
Open `index.html` in your browser.

## Pages
- index.html (Dashboard)
- packages.html
- add-package.html
- staff.html
- branches.html
- reports.html
- settings.html

## Next
Upload each Figma frame PNG and I will replace the scaffold page with pixel-accurate HTML/CSS.
