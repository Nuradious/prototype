# Guyana Post Office - Last-Mile Delivery Tracking System
## Project Structure Documentation

**Last Updated:** January 3, 2026  
**Version:** 2.0 (Staff Portal Priority)

---

## 📋 Overview

This system has been redesigned to prioritize the **Staff/Admin Portal** as the primary interface. All customer-facing pages have been archived and excluded from the main application workflow.

---

## 🗂️ Directory Structure

### **Active Application**

```
/
├── App.tsx                          # Main entry point (Staff Portal only)
├── components/
│   ├── StaffLogin.tsx              # Staff authentication
│   ├── StaffDashboard.tsx          # Main staff dashboard router
│   └── staff/                       # Staff portal pages
│       ├── DashboardLayout.tsx     # Shared layout with sidebar & topbar
│       ├── DashboardPage.tsx       # Dashboard with metrics
│       ├── PackagesPage.tsx        # Package listing & management
│       ├── PackageDetailsPage.tsx  # Individual package details
│       ├── AddPackagePage.tsx      # Add new package & label generation
│       ├── StaffManagementPage.tsx # Staff directory
│       ├── AddStaffMemberPage.tsx  # Add new staff
│       ├── EditStaffMemberPage.tsx # Edit staff details
│       ├── BranchesPage.tsx        # Branch listing
│       ├── EditBranchPage.tsx      # Edit branch details
│       └── MonthlyReportsPage.tsx  # Analytics & reports
```

### **Archived (Customer UI)**

```
/archived/
├── CustomerUI.tsx                   # All customer-facing components
└── README.md                        # Archive documentation
```

### **Shared Resources**

```
/components/
├── ui/                              # shadcn/ui component library
│   ├── button.tsx
│   ├── card.tsx
│   ├── table.tsx
│   ├── dialog.tsx
│   └── ... (30+ components)
└── figma/
    └── ImageWithFallback.tsx        # Protected system component

/styles/
└── globals.css                      # Global styles & design tokens
```

---

## 🎯 Active Features (Staff Portal)

### **Dashboard**
- Real-time metrics and KPIs
- Package statistics
- Delivery performance tracking
- Quick action cards

### **Package Management**
- Comprehensive package listing with filters
- Search functionality
- Status updates and tracking
- Detailed package information
- Timeline visualization

### **Add Package**
- Multi-step package creation form
- Sender and recipient information
- Package details and dimensions
- **Professional shipping label generation:**
  - Standard shipping labels
  - QR code labels
  - Barcode labels
  - Print-ready formats

### **Staff Management**
- Staff directory with search
- Role-based access control
- Add/edit staff members
- Activity tracking

### **Branch Management**
- Branch listing with details
- Edit branch information
- Operating hours management
- Contact information

### **Monthly Reports**
- Analytics dashboard
- Performance charts
- Export capabilities (CSV, PDF, Excel)
- Date range filtering

### **Settings**
- System configuration
- User preferences
- Notification settings

---

## 🗃️ Archived Features (Customer UI)

The following components have been archived to `/archived/CustomerUI.tsx`:

- **Hero** - Customer home page with tracking search
- **Header** - Customer navigation
- **Footer** - Customer footer
- **TrackingResult** - Public tracking interface
- **DeliveryPreference** - Delivery options
- **Services** - Service information
- **Locations** - Branch locations
- **Contact** - Contact form
- **FAQs** - Frequently asked questions

**Status:** ❌ Excluded from main app, prototyping, and exports

---

## 🎨 Design System

### **Color Theme**
- **Primary:** Blue (`#2563eb`) - Guyana Post Office official color
- **Secondary:** White (`#ffffff`)
- **Accent:** Red (`#dc2626`) - Call-to-action and alerts
- **Neutral:** Gray scale for text and backgrounds

### **Typography**
- System defaults configured in `/styles/globals.css`
- No custom Tailwind font classes unless specifically requested

### **Components**
- **UI Library:** shadcn/ui (Radix UI + Tailwind)
- **Icons:** Lucide React
- **Charts:** Recharts
- **Styling:** Tailwind CSS v4.0

---

## 🚀 Application Flow

```
App.tsx (Entry Point)
    │
    ├─── Staff Login ──────> Staff Dashboard
    │                             │
    │                             ├─── Dashboard (default)
    │                             ├─── Packages
    │                             ├─── Add Package
    │                             ├─── Staff Management
    │                             ├─── Branches
    │                             ├─── Reports
    │                             ├─── Settings
    │                             └─── Logout ──> Staff Login
    │
    └─── (Customer UI archived - not accessible)
```

---

## 📦 Key Technologies

- **React** - UI framework
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling
- **shadcn/ui** - Component library
- **Lucide React** - Icons
- **Recharts** - Data visualization
- **QR Code Generation** - Label printing
- **Barcode Generation** - Label printing

---

## 🔒 Protected Files

These system files must not be modified:
- `/components/figma/ImageWithFallback.tsx`

---

## 📝 Notes

1. **Default View:** The application now defaults to the Staff Dashboard on load
2. **Customer UI:** Fully preserved in archived state for potential future use
3. **Staff Portal:** All staff-related pages remain unmodified and fully functional
4. **Design Consistency:** Blue, white, and red color theme maintained throughout
5. **Enterprise Focus:** Professional enterprise dashboard styling for staff users

---

## 🔄 Version History

### Version 2.0 (Current) - January 3, 2026
- ✅ Staff Portal prioritized as main interface
- ✅ Customer UI archived to `/archived/CustomerUI.tsx`
- ✅ Removed customer pages from main app flow
- ✅ Updated routing to staff-only
- ✅ Cleaned up component directory

### Version 1.0 - Previous
- Mixed customer and staff interfaces
- Customer pages as primary experience
- Staff portal as secondary feature

---

**For more information about archived components, see `/archived/README.md`**
