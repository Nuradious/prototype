import { useState } from "react";
import { DashboardLayout } from "./staff/DashboardLayout";
import { DashboardPage } from "./staff/DashboardPage";
import { PackagesPage } from "./staff/PackagesPage";
import { PackageDetailsPage } from "./staff/PackageDetailsPage";
import { AddPackagePage } from "./staff/AddPackagePage";
import { StaffManagementPage } from "./staff/StaffManagementPage";
import { AddStaffMemberPage } from "./staff/AddStaffMemberPage";
import { EditStaffMemberPage } from "./staff/EditStaffMemberPage";
import { BranchesPage } from "./staff/BranchesPage";
import { EditBranchPage } from "./staff/EditBranchPage";
import { MonthlyReportsPage } from "./staff/MonthlyReportsPage";
import { ReportDetailsPage } from "./staff/ReportDetailsPage";

interface StaffDashboardProps {
  onLogout?: () => void;
}

export function StaffDashboard({ onLogout }: StaffDashboardProps) {
  const [activeMenu, setActiveMenu] = useState("dashboard");
  const [selectedPackageId, setSelectedPackageId] = useState<string | null>(null);
  const [showAddStaffForm, setShowAddStaffForm] = useState(false);
  const [editStaffId, setEditStaffId] = useState<string | null>(null);
  const [editBranchId, setEditBranchId] = useState<number | null>(null);
  const [showReportDetails, setShowReportDetails] = useState(false);

  const getPageTitle = () => {
    if (selectedPackageId) {
      return "Package Details";
    }
    if (showAddStaffForm) {
      return "Add Staff Member";
    }
    if (editStaffId) {
      return "Edit Staff Member";
    }
    if (editBranchId) {
      return "Edit Branch";
    }
    if (showReportDetails) {
      return "Report Details";
    }
    switch (activeMenu) {
      case "dashboard":
        return "Dashboard";
      case "packages":
        return "Packages";
      case "add-package":
        return "Add Package";
      case "staff":
        return "Staff Management";
      case "branches":
        return "Branches";
      case "settings":
        return "Settings";
      case "reports":
        return "Monthly Reports";
      default:
        return "Dashboard";
    }
  };

  const getPageSubtitle = () => {
    if (selectedPackageId) {
      return "View and manage package tracking details";
    }
    if (showAddStaffForm) {
      return "Add a new staff member to the system";
    }
    if (editStaffId) {
      return "Update staff member information";
    }
    if (editBranchId) {
      return "Update branch information";
    }
    if (showReportDetails) {
      return "Comprehensive charts and visual analytics";
    }
    switch (activeMenu) {
      case "dashboard":
        return "Welcome back, manage your deliveries";
      case "packages":
        return "Manage and track all packages in the system";
      case "add-package":
        return "Register a new package into the system";
      case "staff":
        return "Manage staff members and permissions";
      case "branches":
        return "Manage post office branches and locations";
      case "settings":
        return "Configure system settings and preferences";
      case "reports":
        return "View monthly reports and analytics";
      default:
        return "";
    }
  };

  const getBreadcrumbs = () => {
    const crumbs: { label: string; onClick?: () => void }[] = [];

    if (selectedPackageId) {
      // Package Details breadcrumbs
      crumbs.push({ label: "Dashboard", onClick: () => setActiveMenu("dashboard") });
      crumbs.push({ label: "Packages", onClick: () => { setActiveMenu("packages"); setSelectedPackageId(null); } });
      crumbs.push({ label: selectedPackageId });
    } else if (showAddStaffForm) {
      // Add Staff Member breadcrumbs
      crumbs.push({ label: "Dashboard", onClick: () => setActiveMenu("dashboard") });
      crumbs.push({ label: "Staff", onClick: () => { setActiveMenu("staff"); setShowAddStaffForm(false); } });
      crumbs.push({ label: "Add Staff Member" });
    } else if (editStaffId) {
      // Edit Staff Member breadcrumbs
      crumbs.push({ label: "Dashboard", onClick: () => setActiveMenu("dashboard") });
      crumbs.push({ label: "Staff", onClick: () => { setActiveMenu("staff"); setEditStaffId(null); } });
      crumbs.push({ label: "Edit Staff Member" });
    } else if (editBranchId) {
      // Edit Branch breadcrumbs
      crumbs.push({ label: "Dashboard", onClick: () => setActiveMenu("dashboard") });
      crumbs.push({ label: "Branches", onClick: () => { setActiveMenu("branches"); setEditBranchId(null); } });
      crumbs.push({ label: "Edit Branch" });
    } else if (showReportDetails) {
      // Report Details breadcrumbs
      crumbs.push({ label: "Dashboard", onClick: () => setActiveMenu("dashboard") });
      crumbs.push({ label: "Reports", onClick: () => { setActiveMenu("reports"); setShowReportDetails(false); } });
      crumbs.push({ label: "Report Details" });
    } else if (activeMenu !== "dashboard") {
      // Other pages breadcrumbs
      crumbs.push({ label: "Dashboard", onClick: () => setActiveMenu("dashboard") });
      
      switch (activeMenu) {
        case "packages":
          crumbs.push({ label: "Packages" });
          break;
        case "add-package":
          crumbs.push({ label: "Packages", onClick: () => setActiveMenu("packages") });
          crumbs.push({ label: "Add Package" });
          break;
        case "staff":
          crumbs.push({ label: "Staff Management" });
          break;
        case "branches":
          crumbs.push({ label: "Branches" });
          break;
        case "settings":
          crumbs.push({ label: "Settings" });
          break;
        case "reports":
          crumbs.push({ label: "Monthly Reports" });
          break;
      }
    }

    return crumbs;
  };

  const handleViewPackage = (trackingNumber: string) => {
    setSelectedPackageId(trackingNumber);
  };

  const handleBackToPackages = () => {
    setSelectedPackageId(null);
  };

  const handleAddStaff = () => {
    setShowAddStaffForm(true);
  };

  const handleEditStaff = (staffId: string) => {
    setEditStaffId(staffId);
  };

  const handleBackToStaffManagement = () => {
    setShowAddStaffForm(false);
    setEditStaffId(null);
  };

  const handleEditBranch = (branchId: number) => {
    setEditBranchId(branchId);
  };

  const handleBackToBranches = () => {
    setEditBranchId(null);
  };

  const handleViewReportDetails = () => {
    setShowReportDetails(true);
  };

  const handleBackToReportSummary = () => {
    setShowReportDetails(false);
  };

  const renderPageContent = () => {
    // If a package is selected, show the details page
    if (selectedPackageId) {
      return (
        <PackageDetailsPage
          trackingNumber={selectedPackageId}
          onBack={handleBackToPackages}
        />
      );
    }

    // If showing add staff form
    if (showAddStaffForm) {
      return (
        <AddStaffMemberPage
          onBack={handleBackToStaffManagement}
        />
      );
    }

    // If editing staff member
    if (editStaffId) {
      return (
        <EditStaffMemberPage
          staffId={editStaffId}
          onBack={handleBackToStaffManagement}
        />
      );
    }

    // If editing branch
    if (editBranchId) {
      return (
        <EditBranchPage
          branchId={editBranchId}
          onBack={handleBackToBranches}
        />
      );
    }

    // If showing report details
    if (showReportDetails) {
      return (
        <ReportDetailsPage
          onBack={handleBackToReportSummary}
        />
      );
    }

    switch (activeMenu) {
      case "dashboard":
        return <DashboardPage />;
      case "packages":
        return <PackagesPage onViewPackage={handleViewPackage} />;
      case "add-package":
        return <AddPackagePage onCancel={() => setActiveMenu("packages")} />;
      case "staff":
        return <StaffManagementPage onAddStaff={handleAddStaff} onEditStaff={handleEditStaff} />;
      case "branches":
        return <BranchesPage onEditBranch={handleEditBranch} />;
      case "reports":
        return <MonthlyReportsPage onViewDetails={handleViewReportDetails} />;
      case "settings":
        return (
          <div className="text-center py-12 text-gray-500">
            Settings page coming soon...
          </div>
        );
      default:
        return <DashboardPage />;
    }
  };

  return (
    <DashboardLayout
      activeMenu={activeMenu}
      onMenuChange={(menu) => {
        setActiveMenu(menu);
        setSelectedPackageId(null); // Clear selected package when changing menu
        setShowAddStaffForm(false); // Clear add staff form when changing menu
        setEditStaffId(null); // Clear edit staff when changing menu
        setEditBranchId(null); // Clear edit branch when changing menu
        setShowReportDetails(false); // Clear report details when changing menu
      }}
      onLogout={onLogout}
      pageTitle={getPageTitle()}
      pageSubtitle={getPageSubtitle()}
      breadcrumbs={getBreadcrumbs()}
    >
      {renderPageContent()}
    </DashboardLayout>
  );
}