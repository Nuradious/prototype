import { useState, FormEvent } from "react";
import { ArrowLeft, User, Mail, Phone, Briefcase, Building2, Shield, Key, Check, X as XIcon, AlertCircle, Lock } from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";

interface EditStaffMemberPageProps {
  staffId: string;
  onBack: () => void;
}

// Mock data - in real app, this would come from props or API
const getStaffData = (staffId: string) => {
  const staffDatabase: { [key: string]: any } = {
    "ST001": {
      fullName: "Robert Chen",
      email: "robert.chen@guyanapost.gy",
      phone: "+592-222-4567",
      role: "Delivery Driver",
      branch: "Diamond",
      status: "Active",
      staffId: "ST001",
    },
    "ST002": {
      fullName: "Sarah Martinez",
      email: "sarah.martinez@guyanapost.gy",
      phone: "+592-222-5678",
      role: "Supervisor",
      branch: "Georgetown",
      status: "Active",
      staffId: "ST002",
    },
    "ST003": {
      fullName: "David Kumar",
      email: "david.kumar@guyanapost.gy",
      phone: "+592-222-6789",
      role: "Branch Manager",
      branch: "Anna Regina",
      status: "Active",
      staffId: "ST003",
    },
    "ST004": {
      fullName: "Jennifer Ali",
      email: "jennifer.ali@guyanapost.gy",
      phone: "+592-222-7890",
      role: "Customs Officer",
      branch: "Linden",
      status: "Active",
      staffId: "ST004",
    },
    "ST005": {
      fullName: "Michael Brown",
      email: "michael.brown@guyanapost.gy",
      phone: "+592-222-8901",
      role: "Sorting Clerk",
      branch: "Georgetown",
      status: "Inactive",
      staffId: "ST005",
    },
  };

  return staffDatabase[staffId] || staffDatabase["ST001"];
};

export function EditStaffMemberPage({ staffId, onBack }: EditStaffMemberPageProps) {
  const staffData = getStaffData(staffId);
  
  const [showSuccessBanner, setShowSuccessBanner] = useState(false);
  const [showErrorBanner, setShowErrorBanner] = useState(false);
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  
  const [formData, setFormData] = useState({
    fullName: staffData.fullName,
    email: staffData.email,
    phone: staffData.phone,
    role: staffData.role,
    branch: staffData.branch,
    status: staffData.status,
    staffId: staffData.staffId,
  });

  const [passwordData, setPasswordData] = useState({
    newPassword: "",
    confirmPassword: "",
  });

  const validateForm = () => {
    const errors: { [key: string]: string } = {};

    // Full Name validation
    if (!formData.fullName.trim()) {
      errors.fullName = "Full name is required";
    } else if (formData.fullName.trim().length < 3) {
      errors.fullName = "Name must be at least 3 characters";
    }

    // Email validation
    if (!formData.email.trim()) {
      errors.email = "Email address is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = "Please enter a valid email address";
    }

    // Phone validation
    if (!formData.phone.trim()) {
      errors.phone = "Phone number is required";
    } else if (!/^\+?[\d\s-()]+$/.test(formData.phone)) {
      errors.phone = "Please enter a valid phone number";
    }

    // Role validation
    if (!formData.role) {
      errors.role = "Please select a role";
    }

    // Branch validation
    if (!formData.branch) {
      errors.branch = "Please select a branch";
    }

    // Password validation (only if passwords are entered)
    if (passwordData.newPassword || passwordData.confirmPassword) {
      if (!passwordData.newPassword) {
        errors.newPassword = "New password is required";
      } else if (passwordData.newPassword.length < 8) {
        errors.newPassword = "Password must be at least 8 characters";
      }

      if (!passwordData.confirmPassword) {
        errors.confirmPassword = "Please confirm password";
      } else if (passwordData.newPassword !== passwordData.confirmPassword) {
        errors.confirmPassword = "Passwords do not match";
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      console.log("Updating staff member:", formData);
      if (passwordData.newPassword) {
        console.log("Updating password for:", staffId);
      }
      
      // Show success banner
      setShowSuccessBanner(true);
      setShowErrorBanner(false);
      
      // Reset password fields
      setPasswordData({
        newPassword: "",
        confirmPassword: "",
      });
      setFormErrors({});

      // Auto-hide banner and navigate back after 3 seconds
      setTimeout(() => {
        setShowSuccessBanner(false);
        onBack();
      }, 3000);
    } else {
      // Show error banner
      setShowErrorBanner(true);
      setShowSuccessBanner(false);
      
      // Auto-hide error banner after 5 seconds
      setTimeout(() => {
        setShowErrorBanner(false);
      }, 5000);
    }
  };

  const handleCancel = () => {
    // Reset to original data and go back
    setFormData({
      fullName: staffData.fullName,
      email: staffData.email,
      phone: staffData.phone,
      role: staffData.role,
      branch: staffData.branch,
      status: staffData.status,
      staffId: staffData.staffId,
    });
    setPasswordData({
      newPassword: "",
      confirmPassword: "",
    });
    setFormErrors({});
    onBack();
  };

  return (
    <div className="space-y-6">
      {/* Success Banner */}
      {showSuccessBanner && (
        <Card className="p-4 bg-green-50 border-green-200 animate-in slide-in-from-top">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <Check className="w-5 h-5 text-green-600" />
            </div>
            <div className="flex-1">
              <h4 className="text-green-900">Success!</h4>
              <p className="text-sm text-green-700">Staff member updated successfully. Redirecting...</p>
            </div>
            <button
              onClick={() => setShowSuccessBanner(false)}
              className="text-green-600 hover:text-green-700"
            >
              <XIcon className="w-5 h-5" />
            </button>
          </div>
        </Card>
      )}

      {/* Error Banner */}
      {showErrorBanner && (
        <Card className="p-4 bg-red-50 border-red-200 animate-in slide-in-from-top">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-red-600" />
            </div>
            <div className="flex-1">
              <h4 className="text-red-900">Error!</h4>
              <p className="text-sm text-red-700">Please fix the errors below and try again.</p>
            </div>
            <button
              onClick={() => setShowErrorBanner(false)}
              className="text-red-600 hover:text-red-700"
            >
              <XIcon className="w-5 h-5" />
            </button>
          </div>
        </Card>
      )}

      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={onBack}
        className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Staff Management
      </Button>

      {/* Form Card */}
      <Card className="p-8">
        <div className="mb-8">
          <h3 className="text-gray-900 mb-2">Edit Staff Member – {formData.fullName}</h3>
          <p className="text-sm text-gray-600">
            Update the staff member's information below.
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Basic Information Section */}
          <div className="mb-8">
            <h4 className="text-gray-900 mb-6 pb-3 border-b border-gray-200">
              Basic Information
            </h4>
            <div className="grid md:grid-cols-2 gap-6">
              {/* Full Name */}
              <div>
                <Label htmlFor="fullName" className="text-gray-700 mb-2 block">
                  Full Name <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="fullName"
                    type="text"
                    placeholder="e.g., John Smith"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className={`pl-10 h-11 border-2 ${formErrors.fullName ? "border-red-300 focus:border-red-500" : ""}`}
                  />
                </div>
                {formErrors.fullName && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.fullName}
                  </p>
                )}
              </div>

              {/* Email Address */}
              <div>
                <Label htmlFor="email" className="text-gray-700 mb-2 block">
                  Email Address <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="e.g., john.smith@guyanapost.gy"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`pl-10 h-11 border-2 ${formErrors.email ? "border-red-300 focus:border-red-500" : ""}`}
                  />
                </div>
                {formErrors.email && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.email}
                  </p>
                )}
              </div>

              {/* Phone Number */}
              <div>
                <Label htmlFor="phone" className="text-gray-700 mb-2 block">
                  Phone Number <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="e.g., +592-222-3456"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className={`pl-10 h-11 border-2 ${formErrors.phone ? "border-red-300 focus:border-red-500" : ""}`}
                  />
                </div>
                {formErrors.phone && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.phone}
                  </p>
                )}
              </div>

              {/* Staff ID (Read-only) */}
              <div>
                <Label htmlFor="staffId" className="text-gray-700 mb-2 block">
                  Staff ID <span className="text-gray-500">(Read-only)</span>
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="staffId"
                    type="text"
                    value={formData.staffId}
                    className="pl-10 h-11 border-2 bg-gray-100 cursor-not-allowed"
                    disabled
                    readOnly
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Staff ID cannot be changed
                </p>
              </div>

              {/* Role */}
              <div>
                <Label htmlFor="role" className="text-gray-700 mb-2 block">
                  Role <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 z-10 pointer-events-none" />
                  <Select
                    value={formData.role}
                    onValueChange={(value) => setFormData({ ...formData, role: value })}
                  >
                    <SelectTrigger
                      id="role"
                      className={`h-11 border-2 pl-10 ${formErrors.role ? "border-red-300 focus:border-red-500" : ""}`}
                    >
                      <SelectValue placeholder="Select role..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Delivery Driver">Delivery Driver</SelectItem>
                      <SelectItem value="Supervisor">Supervisor</SelectItem>
                      <SelectItem value="Branch Manager">Branch Manager</SelectItem>
                      <SelectItem value="Customs Officer">Customs Officer</SelectItem>
                      <SelectItem value="Sorting Clerk">Sorting Clerk</SelectItem>
                      <SelectItem value="Delivery Manager">Delivery Manager</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {formErrors.role && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.role}
                  </p>
                )}
              </div>

              {/* Branch */}
              <div>
                <Label htmlFor="branch" className="text-gray-700 mb-2 block">
                  Branch <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 z-10 pointer-events-none" />
                  <Select
                    value={formData.branch}
                    onValueChange={(value) => setFormData({ ...formData, branch: value })}
                  >
                    <SelectTrigger
                      id="branch"
                      className={`h-11 border-2 pl-10 ${formErrors.branch ? "border-red-300 focus:border-red-500" : ""}`}
                    >
                      <SelectValue placeholder="Select branch..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Georgetown">Georgetown Central</SelectItem>
                      <SelectItem value="Diamond">Diamond</SelectItem>
                      <SelectItem value="New Amsterdam">New Amsterdam</SelectItem>
                      <SelectItem value="Linden">Linden</SelectItem>
                      <SelectItem value="Anna Regina">Anna Regina</SelectItem>
                      <SelectItem value="Bartica">Bartica</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {formErrors.branch && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.branch}
                  </p>
                )}
              </div>

              {/* Status */}
              <div>
                <Label htmlFor="status" className="text-gray-700 mb-2 block">
                  Status <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 z-10 pointer-events-none" />
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger id="status" className="h-11 border-2 pl-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>

          {/* Password Reset Section */}
          <div className="mb-8">
            <h4 className="text-gray-900 mb-2 pb-3 border-b border-gray-200">
              Reset Password (Optional)
            </h4>
            <p className="text-sm text-gray-600 mb-6">
              Leave these fields empty if you don't want to change the password.
            </p>
            <div className="grid md:grid-cols-2 gap-6">
              {/* New Password */}
              <div>
                <Label htmlFor="newPassword" className="text-gray-700 mb-2 block">
                  New Password
                </Label>
                <div className="relative">
                  <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="newPassword"
                    type="password"
                    placeholder="Enter new password"
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                    className={`pl-10 h-11 border-2 ${formErrors.newPassword ? "border-red-300 focus:border-red-500" : ""}`}
                  />
                </div>
                {formErrors.newPassword && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.newPassword}
                  </p>
                )}
                {!formErrors.newPassword && (
                  <p className="text-xs text-gray-500 mt-1">
                    Must be at least 8 characters
                  </p>
                )}
              </div>

              {/* Confirm New Password */}
              <div>
                <Label htmlFor="confirmPassword" className="text-gray-700 mb-2 block">
                  Confirm New Password
                </Label>
                <div className="relative">
                  <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm new password"
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                    className={`pl-10 h-11 border-2 ${formErrors.confirmPassword ? "border-red-300 focus:border-red-500" : ""}`}
                  />
                </div>
                {formErrors.confirmPassword && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.confirmPassword}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-4 pt-6 border-t border-gray-200">
            <Button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-8"
            >
              <Check className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
              className="border-2 h-11 px-8"
            >
              Cancel
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
