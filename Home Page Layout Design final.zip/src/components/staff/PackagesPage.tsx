import { useState } from "react";
import { Search, Filter, Eye, Edit, X, ChevronLeft, ChevronRight, PackageX } from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Badge } from "../ui/badge";
import { Label } from "../ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";

interface PackagesPageProps {
  onViewPackage?: (trackingNumber: string) => void;
}

const packagesData = [
  {
    id: 1,
    trackingNumber: "GY123456789",
    receiver: "John Smith",
    status: "Out for Delivery",
    statusColor: "orange",
    lastUpdate: "2024-01-16 10:30 AM",
    deliveryOption: "Home",
    branch: "Georgetown",
  },
  {
    id: 2,
    trackingNumber: "GY987654321",
    receiver: "Sarah Johnson",
    status: "Delivered",
    statusColor: "green",
    lastUpdate: "2024-01-16 09:45 AM",
    deliveryOption: "Home",
    branch: "Diamond",
  },
  {
    id: 3,
    trackingNumber: "GY456789123",
    receiver: "Michael Brown",
    status: "In Transit",
    statusColor: "blue",
    lastUpdate: "2024-01-16 08:15 AM",
    deliveryOption: "Pickup",
    branch: "New Amsterdam",
  },
  {
    id: 4,
    trackingNumber: "GY789123456",
    receiver: "Emily Davis",
    status: "In Transit",
    statusColor: "blue",
    lastUpdate: "2024-01-16 07:20 AM",
    deliveryOption: "Home",
    branch: "Georgetown",
  },
  {
    id: 5,
    trackingNumber: "GY321654987",
    receiver: "David Wilson",
    status: "Delayed",
    statusColor: "red",
    lastUpdate: "2024-01-15 04:30 PM",
    deliveryOption: "Home",
    branch: "Linden",
  },
  {
    id: 6,
    trackingNumber: "GY654987321",
    receiver: "Lisa Anderson",
    status: "Out for Delivery",
    statusColor: "orange",
    lastUpdate: "2024-01-16 11:00 AM",
    deliveryOption: "Pickup",
    branch: "Georgetown",
  },
  {
    id: 7,
    trackingNumber: "GY147258369",
    receiver: "Robert Martinez",
    status: "In Transit",
    statusColor: "blue",
    lastUpdate: "2024-01-16 06:45 AM",
    deliveryOption: "Home",
    branch: "Diamond",
  },
  {
    id: 8,
    trackingNumber: "GY963852741",
    receiver: "Jennifer Taylor",
    status: "Delivered",
    statusColor: "green",
    lastUpdate: "2024-01-16 08:30 AM",
    deliveryOption: "Pickup",
    branch: "Georgetown",
  },
  {
    id: 9,
    trackingNumber: "GY258369147",
    receiver: "Christopher Lee",
    status: "Out for Delivery",
    statusColor: "orange",
    lastUpdate: "2024-01-16 10:15 AM",
    deliveryOption: "Home",
    branch: "Linden",
  },
  {
    id: 10,
    trackingNumber: "GY741852963",
    receiver: "Amanda White",
    status: "In Transit",
    statusColor: "blue",
    lastUpdate: "2024-01-16 09:00 AM",
    deliveryOption: "Home",
    branch: "New Amsterdam",
  },
];

export function PackagesPage({ onViewPackage }: PackagesPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [branchFilter, setBranchFilter] = useState("all");
  const [deliveryOptionFilter, setDeliveryOptionFilter] = useState("all");
  const [dateRangeFilter, setDateRangeFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  const getStatusColor = (color: string) => {
    const colors: { [key: string]: string } = {
      blue: "bg-blue-100 text-blue-700 border-blue-200",
      orange: "bg-orange-100 text-orange-700 border-orange-200",
      green: "bg-green-100 text-green-700 border-green-200",
      red: "bg-red-100 text-red-700 border-red-200",
    };
    return colors[color] || colors.blue;
  };

  const filteredPackages = packagesData.filter((pkg) => {
    const matchesSearch =
      searchQuery === "" ||
      pkg.trackingNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pkg.receiver.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || pkg.status === statusFilter;

    const matchesBranch =
      branchFilter === "all" || pkg.branch === branchFilter;

    const matchesDeliveryOption =
      deliveryOptionFilter === "all" || pkg.deliveryOption === deliveryOptionFilter;

    return matchesSearch && matchesStatus && matchesBranch && matchesDeliveryOption;
  });

  // Pagination
  const totalPages = Math.ceil(filteredPackages.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentPackages = filteredPackages.slice(startIndex, endIndex);

  const handleResetFilters = () => {
    setSearchQuery("");
    setStatusFilter("all");
    setBranchFilter("all");
    setDeliveryOptionFilter("all");
    setDateRangeFilter("all");
    setCurrentPage(1);
  };

  const hasActiveFilters = 
    searchQuery !== "" || 
    statusFilter !== "all" || 
    branchFilter !== "all" || 
    deliveryOptionFilter !== "all" || 
    dateRangeFilter !== "all";

  return (
    <div className="space-y-6">
      {/* Filters Card */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-gray-900 flex items-center gap-2">
            <Filter className="w-5 h-5 text-blue-600" />
            Filters
          </h3>
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleResetFilters}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <X className="w-4 h-4 mr-1" />
              Reset Filters
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* Search Bar */}
          <div>
            <Label className="text-gray-700 mb-2 block text-sm">Search</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Tracking number..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="pl-10 h-11 border-2"
              />
            </div>
          </div>

          {/* Status Filter */}
          <div>
            <Label className="text-gray-700 mb-2 block text-sm">Status</Label>
            <Select 
              value={statusFilter} 
              onValueChange={(value) => {
                setStatusFilter(value);
                setCurrentPage(1);
              }}
            >
              <SelectTrigger className="h-11 border-2">
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="In Transit">In Transit</SelectItem>
                <SelectItem value="Out for Delivery">Out for Delivery</SelectItem>
                <SelectItem value="Delivered">Delivered</SelectItem>
                <SelectItem value="Delayed">Delayed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Branch Filter */}
          <div>
            <Label className="text-gray-700 mb-2 block text-sm">Branch</Label>
            <Select 
              value={branchFilter} 
              onValueChange={(value) => {
                setBranchFilter(value);
                setCurrentPage(1);
              }}
            >
              <SelectTrigger className="h-11 border-2">
                <SelectValue placeholder="All Branches" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Branches</SelectItem>
                <SelectItem value="Georgetown">Georgetown</SelectItem>
                <SelectItem value="Diamond">Diamond</SelectItem>
                <SelectItem value="New Amsterdam">New Amsterdam</SelectItem>
                <SelectItem value="Linden">Linden</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Delivery Option Filter */}
          <div>
            <Label className="text-gray-700 mb-2 block text-sm">Delivery Option</Label>
            <Select 
              value={deliveryOptionFilter} 
              onValueChange={(value) => {
                setDeliveryOptionFilter(value);
                setCurrentPage(1);
              }}
            >
              <SelectTrigger className="h-11 border-2">
                <SelectValue placeholder="All Options" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Options</SelectItem>
                <SelectItem value="Home">Home Delivery</SelectItem>
                <SelectItem value="Pickup">Pickup</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Date Range Filter */}
          <div>
            <Label className="text-gray-700 mb-2 block text-sm">Date Range</Label>
            <Select 
              value={dateRangeFilter} 
              onValueChange={(value) => {
                setDateRangeFilter(value);
                setCurrentPage(1);
              }}
            >
              <SelectTrigger className="h-11 border-2">
                <SelectValue placeholder="All Time" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="yesterday">Yesterday</SelectItem>
                <SelectItem value="last7days">Last 7 Days</SelectItem>
                <SelectItem value="last30days">Last 30 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Results Count */}
        <div className="mt-4 pt-4 border-t border-gray-200 flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Showing <span className="text-gray-900">{startIndex + 1}-{Math.min(endIndex, filteredPackages.length)}</span> of{" "}
            <span className="text-gray-900">{filteredPackages.length}</span> packages
          </p>
          {hasActiveFilters && (
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              {Object.values({ statusFilter, branchFilter, deliveryOptionFilter, dateRangeFilter }).filter(v => v !== "all").length} filters active
            </Badge>
          )}
        </div>
      </Card>

      {/* Packages Table */}
      <Card className="p-6">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>Tracking Number</TableHead>
                <TableHead>Receiver</TableHead>
                <TableHead>Current Status</TableHead>
                <TableHead>Last Update</TableHead>
                <TableHead>Delivery Option</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentPackages.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12">
                    <div className="flex flex-col items-center gap-3">
                      <PackageX className="w-12 h-12 text-gray-400" />
                      <div>
                        <p className="text-gray-900 mb-1">No packages found</p>
                        <p className="text-sm text-gray-500">
                          {hasActiveFilters 
                            ? "Try adjusting your filters or search query"
                            : "No packages available at this time"}
                        </p>
                      </div>
                      {hasActiveFilters && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleResetFilters}
                          className="mt-2"
                        >
                          Clear all filters
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                currentPackages.map((pkg, index) => (
                  <TableRow 
                    key={pkg.id} 
                    className={`hover:bg-blue-50 transition-colors ${
                      index % 2 === 0 ? "bg-white" : "bg-gray-50"
                    }`}
                  >
                    <TableCell className="font-medium text-blue-600">
                      {pkg.trackingNumber}
                    </TableCell>
                    <TableCell className="text-gray-900">{pkg.receiver}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`${getStatusColor(pkg.statusColor)} border`}
                      >
                        {pkg.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-600 text-sm">
                      {pkg.lastUpdate}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`${
                          pkg.deliveryOption === "Home"
                            ? "bg-purple-100 text-purple-700 border-purple-200"
                            : "bg-teal-100 text-teal-700 border-teal-200"
                        } border`}
                      >
                        {pkg.deliveryOption}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                          onClick={() => onViewPackage && onViewPackage(pkg.trackingNumber)}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                          onClick={() => onViewPackage && onViewPackage(pkg.trackingNumber)}
                        >
                          <Edit className="w-4 h-4 mr-1" />
                          Update
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="mt-6 pt-6 border-t border-gray-200 flex items-center justify-between">
            <p className="text-sm text-gray-600">
              Page {currentPage} of {totalPages}
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Previous
              </Button>
              
              <div className="flex gap-1">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(page)}
                    className={currentPage === page ? "bg-blue-600 hover:bg-blue-700" : ""}
                  >
                    {page}
                  </Button>
                ))}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}