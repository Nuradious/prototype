import { useState, FormEvent } from "react";
import { ArrowLeft, Building2, MapPin, Phone, Mail, UserCircle, Shield, Check, X as XIcon, AlertCircle, Users, Package, CheckCircle } from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";

interface EditBranchPageProps {
  branchId: number;
  onBack: () => void;
}

// Mock data - in real app, this would come from props or API
const getBranchData = (branchId: number) => {
  const branchDatabase: { [key: number]: any } = {
    1: {
      name: "Georgetown Central",
      address: "Robb Street, Georgetown",
      phone: "+592-226-4211",
      email: "georgetown@guyanapost.gy",
      manager: "Michelle Williams",
      status: "Active",
      totalStaff: 24,
      activePackages: 156,
      completedPackages: 1247,
    },
    2: {
      name: "Diamond",
      address: "Diamond, East Bank Demerara",
      phone: "+592-265-3456",
      email: "diamond@guyanapost.gy",
      manager: "Robert Chen",
      status: "Active",
      totalStaff: 12,
      activePackages: 78,
      completedPackages: 892,
    },
    3: {
      name: "New Amsterdam",
      address: "Main Street, New Amsterdam",
      phone: "+592-333-2211",
      email: "newamsterdam@guyanapost.gy",
      manager: "James Taylor",
      status: "Active",
      totalStaff: 15,
      activePackages: 92,
      completedPackages: 1034,
    },
    4: {
      name: "Linden",
      address: "Mackenzie, Linden",
      phone: "+592-444-5678",
      email: "linden@guyanapost.gy",
      manager: "Jennifer Ali",
      status: "Active",
      totalStaff: 10,
      activePackages: 45,
      completedPackages: 678,
    },
    5: {
      name: "Anna Regina",
      address: "Anna Regina, Essequibo Coast",
      phone: "+592-771-2345",
      email: "annaregina@guyanapost.gy",
      manager: "David Kumar",
      status: "Active",
      totalStaff: 8,
      activePackages: 34,
      completedPackages: 512,
    },
    6: {
      name: "Bartica",
      address: "First Avenue, Bartica",
      phone: "+592-455-1234",
      email: "bartica@guyanapost.gy",
      manager: "Christopher Lee",
      status: "Active",
      totalStaff: 6,
      activePackages: 21,
      completedPackages: 345,
    },
  };

  return branchDatabase[branchId] || branchDatabase[1];
};

export function EditBranchPage({ branchId, onBack }: EditBranchPageProps) {
  const branchData = getBranchData(branchId);
  
  const [showSuccessBanner, setShowSuccessBanner] = useState(false);
  const [showErrorBanner, setShowErrorBanner] = useState(false);
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  
  const [formData, setFormData] = useState({
    name: branchData.name,
    address: branchData.address,
    phone: branchData.phone,
    email: branchData.email,
    manager: branchData.manager,
    status: branchData.status,
  });

  const validateForm = () => {
    const errors: { [key: string]: string } = {};

    // Branch Name validation
    if (!formData.name.trim()) {
      errors.name = "Branch name is required";
    } else if (formData.name.trim().length < 3) {
      errors.name = "Branch name must be at least 3 characters";
    }

    // Address validation
    if (!formData.address.trim()) {
      errors.address = "Address is required";
    } else if (formData.address.trim().length < 10) {
      errors.address = "Please enter a complete address";
    }

    // Phone validation
    if (!formData.phone.trim()) {
      errors.phone = "Phone number is required";
    } else if (!/^\+?[\d\s-()]+$/.test(formData.phone)) {
      errors.phone = "Please enter a valid phone number";
    }

    // Email validation
    if (!formData.email.trim()) {
      errors.email = "Email address is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = "Please enter a valid email address";
    }

    // Manager validation
    if (!formData.manager) {
      errors.manager = "Please select a branch manager";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      console.log("Updating branch:", formData);
      
      // Show success banner
      setShowSuccessBanner(true);
      setShowErrorBanner(false);
      setFormErrors({});

      // Auto-hide banner and navigate back after 3 seconds
      setTimeout(() => {
        setShowSuccessBanner(false);
        onBack();
      }, 3000);
    } else {
      // Show error banner
      setShowErrorBanner(true);
      setShowSuccessBanner(false);
      
      // Auto-hide error banner after 5 seconds
      setTimeout(() => {
        setShowErrorBanner(false);
      }, 5000);
    }
  };

  const handleCancel = () => {
    // Reset to original data and go back
    setFormData({
      name: branchData.name,
      address: branchData.address,
      phone: branchData.phone,
      email: branchData.email,
      manager: branchData.manager,
      status: branchData.status,
    });
    setFormErrors({});
    onBack();
  };

  return (
    <div className="space-y-6">
      {/* Success Banner */}
      {showSuccessBanner && (
        <Card className="p-4 bg-green-50 border-green-200 animate-in slide-in-from-top">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <Check className="w-5 h-5 text-green-600" />
            </div>
            <div className="flex-1">
              <h4 className="text-green-900">Success!</h4>
              <p className="text-sm text-green-700">Branch updated successfully. Redirecting...</p>
            </div>
            <button
              onClick={() => setShowSuccessBanner(false)}
              className="text-green-600 hover:text-green-700"
            >
              <XIcon className="w-5 h-5" />
            </button>
          </div>
        </Card>
      )}

      {/* Error Banner */}
      {showErrorBanner && (
        <Card className="p-4 bg-red-50 border-red-200 animate-in slide-in-from-top">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-red-600" />
            </div>
            <div className="flex-1">
              <h4 className="text-red-900">Error!</h4>
              <p className="text-sm text-red-700">Please fix the errors below and try again.</p>
            </div>
            <button
              onClick={() => setShowErrorBanner(false)}
              className="text-red-600 hover:text-red-700"
            >
              <XIcon className="w-5 h-5" />
            </button>
          </div>
        </Card>
      )}

      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={onBack}
        className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Branches
      </Button>

      {/* Read-only Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6 border-l-4 border-l-blue-600">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Staff</p>
              <h3 className="text-gray-900">{branchData.totalStaff}</h3>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-l-orange-600">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Active Packages</p>
              <h3 className="text-gray-900">{branchData.activePackages}</h3>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Package className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-l-green-600">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Completed Packages</p>
              <h3 className="text-gray-900">{branchData.completedPackages}</h3>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Form Card */}
      <Card className="p-8">
        <div className="mb-8">
          <h3 className="text-gray-900 mb-2">Edit Branch – {formData.name}</h3>
          <p className="text-sm text-gray-600">
            Update the branch information below.
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Branch Information Section */}
          <div className="mb-8">
            <h4 className="text-gray-900 mb-6 pb-3 border-b border-gray-200">
              Branch Information
            </h4>
            <div className="grid md:grid-cols-2 gap-6">
              {/* Branch Name */}
              <div>
                <Label htmlFor="name" className="text-gray-700 mb-2 block">
                  Branch Name <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="name"
                    type="text"
                    placeholder="e.g., Georgetown Central"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className={`pl-10 h-11 border-2 ${formErrors.name ? "border-red-300 focus:border-red-500" : ""}`}
                  />
                </div>
                {formErrors.name && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.name}
                  </p>
                )}
              </div>

              {/* Branch Manager */}
              <div>
                <Label htmlFor="manager" className="text-gray-700 mb-2 block">
                  Branch Manager <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <UserCircle className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 z-10 pointer-events-none" />
                  <Select
                    value={formData.manager}
                    onValueChange={(value) => setFormData({ ...formData, manager: value })}
                  >
                    <SelectTrigger
                      id="manager"
                      className={`h-11 border-2 pl-10 ${formErrors.manager ? "border-red-300 focus:border-red-500" : ""}`}
                    >
                      <SelectValue placeholder="Select manager..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Michelle Williams">Michelle Williams</SelectItem>
                      <SelectItem value="Robert Chen">Robert Chen</SelectItem>
                      <SelectItem value="David Kumar">David Kumar</SelectItem>
                      <SelectItem value="Jennifer Ali">Jennifer Ali</SelectItem>
                      <SelectItem value="James Taylor">James Taylor</SelectItem>
                      <SelectItem value="Christopher Lee">Christopher Lee</SelectItem>
                      <SelectItem value="Kevin Thompson">Kevin Thompson</SelectItem>
                      <SelectItem value="Sarah Martinez">Sarah Martinez</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {formErrors.manager && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.manager}
                  </p>
                )}
              </div>

              {/* Address / Location */}
              <div className="md:col-span-2">
                <Label htmlFor="address" className="text-gray-700 mb-2 block">
                  Address / Location <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <Textarea
                    id="address"
                    placeholder="Enter complete address..."
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className={`pl-10 border-2 resize-none ${formErrors.address ? "border-red-300 focus:border-red-500" : ""}`}
                    rows={3}
                  />
                </div>
                {formErrors.address && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.address}
                  </p>
                )}
              </div>

              {/* Contact Phone Number */}
              <div>
                <Label htmlFor="phone" className="text-gray-700 mb-2 block">
                  Contact Phone Number <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="e.g., +592-226-4211"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className={`pl-10 h-11 border-2 ${formErrors.phone ? "border-red-300 focus:border-red-500" : ""}`}
                  />
                </div>
                {formErrors.phone && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.phone}
                  </p>
                )}
              </div>

              {/* Contact Email */}
              <div>
                <Label htmlFor="email" className="text-gray-700 mb-2 block">
                  Contact Email <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="e.g., branch@guyanapost.gy"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`pl-10 h-11 border-2 ${formErrors.email ? "border-red-300 focus:border-red-500" : ""}`}
                  />
                </div>
                {formErrors.email && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {formErrors.email}
                  </p>
                )}
              </div>

              {/* Status */}
              <div>
                <Label htmlFor="status" className="text-gray-700 mb-2 block">
                  Status <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 z-10 pointer-events-none" />
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger id="status" className="h-11 border-2 pl-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-4 pt-6 border-t border-gray-200">
            <Button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-8"
            >
              <Check className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
              className="border-2 h-11 px-8"
            >
              Cancel
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
