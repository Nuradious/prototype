import {
  Package,
  Truck,
  CheckCircle,
  AlertCircle,
  Eye,
  AlertTriangle,
  Clock,
  RefreshCw,
} from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";

const stats = [
  {
    id: 1,
    title: "Total Packages Today",
    value: "247",
    icon: Package,
    color: "blue",
    bgColor: "bg-blue-100",
    iconColor: "text-blue-600",
  },
  {
    id: 2,
    title: "Out for Delivery",
    value: "68",
    icon: Truck,
    color: "orange",
    bgColor: "bg-orange-100",
    iconColor: "text-orange-600",
  },
  {
    id: 3,
    title: "Delivered Today",
    value: "142",
    icon: CheckCircle,
    color: "green",
    bgColor: "bg-green-100",
    iconColor: "text-green-600",
  },
  {
    id: 4,
    title: "Delayed",
    value: "12",
    icon: AlertCircle,
    color: "red",
    bgColor: "bg-red-100",
    iconColor: "text-red-600",
  },
];

const recentPackages = [
  {
    id: 1,
    trackingNumber: "GY123456789",
    receiver: "John Smith",
    status: "Out for Delivery",
    statusColor: "orange",
    lastUpdated: "10 mins ago",
    branch: "Georgetown",
  },
  {
    id: 2,
    trackingNumber: "GY987654321",
    receiver: "Sarah Johnson",
    status: "Delivered",
    statusColor: "green",
    lastUpdated: "25 mins ago",
    branch: "Diamond",
  },
  {
    id: 3,
    trackingNumber: "GY456789123",
    receiver: "Michael Brown",
    status: "In Transit",
    statusColor: "blue",
    lastUpdated: "1 hour ago",
    branch: "New Amsterdam",
  },
  {
    id: 4,
    trackingNumber: "GY789123456",
    receiver: "Emily Davis",
    status: "Customs Clearance",
    statusColor: "purple",
    lastUpdated: "2 hours ago",
    branch: "Georgetown",
  },
  {
    id: 5,
    trackingNumber: "GY321654987",
    receiver: "David Wilson",
    status: "Delayed",
    statusColor: "red",
    lastUpdated: "3 hours ago",
    branch: "Linden",
  },
  {
    id: 6,
    trackingNumber: "GY654987321",
    receiver: "Lisa Anderson",
    status: "Out for Delivery",
    statusColor: "orange",
    lastUpdated: "4 hours ago",
    branch: "Georgetown",
  },
];

const flaggedPackages = [
  {
    id: 1,
    trackingNumber: "GY321654987",
    receiver: "David Wilson",
    issue: "Delayed at Customs",
    issueType: "delayed",
    lastUpdate: "3 hours ago",
    priority: "high",
  },
  {
    id: 2,
    trackingNumber: "GY741852963",
    receiver: "Amanda White",
    issue: "Delivery Attempt Failed",
    issueType: "exception",
    lastUpdate: "5 hours ago",
    priority: "medium",
  },
  {
    id: 3,
    trackingNumber: "GY987654321",
    receiver: "Sarah Johnson",
    issue: "Address Verification Required",
    issueType: "exception",
    lastUpdate: "1 day ago",
    priority: "medium",
  },
  {
    id: 4,
    trackingNumber: "GY456123789",
    receiver: "Michael Chen",
    issue: "Customs Hold",
    issueType: "customs",
    lastUpdate: "2 days ago",
    priority: "high",
  },
];

export function DashboardPage() {
  const getStatusColor = (color: string) => {
    const colors: { [key: string]: string } = {
      blue: "bg-blue-100 text-blue-700 border-blue-200",
      orange: "bg-orange-100 text-orange-700 border-orange-200",
      green: "bg-green-100 text-green-700 border-green-200",
      purple: "bg-purple-100 text-purple-700 border-purple-200",
      red: "bg-red-100 text-red-700 border-red-200",
    };
    return colors[color] || colors.blue;
  };

  const getIssueColor = (type: string) => {
    const colors: { [key: string]: string } = {
      delayed: "bg-red-100 text-red-700 border-red-200",
      exception: "bg-orange-100 text-orange-700 border-orange-200",
      customs: "bg-purple-100 text-purple-700 border-purple-200",
    };
    return colors[type] || colors.orange;
  };

  const getPriorityColor = (priority: string) => {
    const colors: { [key: string]: string } = {
      high: "bg-red-600",
      medium: "bg-orange-600",
      low: "bg-blue-600",
    };
    return colors[priority] || colors.medium;
  };

  const lastSyncTime = new Date().toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });

  return (
    <div className="space-y-8">
      {/* Last Sync Indicator */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <RefreshCw className="w-4 h-4" />
          <span>Last updated: {lastSyncTime}</span>
        </div>
        <Button variant="outline" size="sm" className="border-2">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh Data
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.id} className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div
                  className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}
                >
                  <Icon className={`w-6 h-6 ${stat.iconColor}`} />
                </div>
              </div>
              <h3 className="text-gray-900 mb-1">{stat.value}</h3>
              <p className="text-sm text-gray-600">{stat.title}</p>
            </Card>
          );
        })}
      </div>

      {/* Flagged Packages Section */}
      <Card className="p-6 border-l-4 border-l-red-500">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-gray-900 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            Flagged Packages
            <Badge
              variant="outline"
              className="bg-red-100 text-red-700 border-red-200"
            >
              {flaggedPackages.length}
            </Badge>
          </h3>
          <Button
            variant="outline"
            className="border-red-600 text-red-600 hover:bg-red-50"
          >
            View All Issues
          </Button>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>Priority</TableHead>
                <TableHead>Tracking Number</TableHead>
                <TableHead>Receiver</TableHead>
                <TableHead>Issue</TableHead>
                <TableHead>Last Update</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {flaggedPackages.map((pkg) => (
                <TableRow key={pkg.id} className="hover:bg-red-50">
                  <TableCell>
                    <div
                      className={`w-3 h-3 rounded-full ${getPriorityColor(
                        pkg.priority
                      )}`}
                    ></div>
                  </TableCell>
                  <TableCell className="font-medium text-blue-600">
                    {pkg.trackingNumber}
                  </TableCell>
                  <TableCell className="text-gray-900">{pkg.receiver}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={`${getIssueColor(pkg.issueType)} border`}
                    >
                      {pkg.issue}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-gray-600 text-sm">
                    {pkg.lastUpdate}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Resolve
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Recent Packages Table */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-gray-900">Recent Packages</h3>
          <Button
            variant="outline"
            className="border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            View All
          </Button>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>Tracking Number</TableHead>
                <TableHead>Receiver</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Updated</TableHead>
                <TableHead>Branch</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentPackages.map((pkg, index) => (
                <TableRow
                  key={pkg.id}
                  className={`hover:bg-blue-50 transition-colors ${
                    index % 2 === 0 ? "bg-white" : "bg-gray-50"
                  }`}
                >
                  <TableCell className="font-medium text-blue-600">
                    {pkg.trackingNumber}
                  </TableCell>
                  <TableCell className="text-gray-900">{pkg.receiver}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={`${getStatusColor(pkg.statusColor)} border`}
                    >
                      {pkg.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-gray-600">{pkg.lastUpdated}</TableCell>
                  <TableCell className="text-gray-600">{pkg.branch}</TableCell>
                  <TableCell className="text-right">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}