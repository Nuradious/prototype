import { useState } from "react";
import { Package, ArrowLeft, FileDown, Printer, Sparkles, Tag } from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { QRCodeSVG } from "qrcode.react";

interface AddPackagePageProps {
  onCancel?: () => void;
}

export function AddPackagePage({ onCancel }: AddPackagePageProps) {
  const [formData, setFormData] = useState({
    trackingNumber: "",
    senderName: "",
    receiverName: "",
    receiverPhone: "",
    originCountry: "",
    destinationAddress: "",
    branch: "",
    packageType: "",
    weight: "",
  });

  const [labelType, setLabelType] = useState("Standard");
  const [labelGenerated, setLabelGenerated] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      console.log("Creating package:", formData);
      setIsSubmitting(false);
      // Reset form or navigate away
      setFormData({
        trackingNumber: "",
        senderName: "",
        receiverName: "",
        receiverPhone: "",
        originCountry: "",
        destinationAddress: "",
        branch: "",
        packageType: "",
        weight: "",
      });
      // Show success message or redirect
    }, 1500);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleGenerateLabel = () => {
    if (!formData.trackingNumber || !formData.receiverName || !formData.destinationAddress) {
      alert("Please fill in all required package fields before generating a label.");
      return;
    }
    setLabelGenerated(true);
  };

  const handleDownloadPDF = () => {
    alert("Label PDF download functionality would be implemented here.");
    console.log("Downloading label as PDF...");
  };

  const handlePrintLabel = () => {
    window.print();
  };

  const getLabelTypeColor = () => {
    switch (labelType) {
      case "Express":
        return "bg-red-100 text-red-800 border-red-300";
      case "Fragile":
        return "bg-orange-100 text-orange-800 border-orange-300";
      case "Heavy":
        return "bg-purple-100 text-purple-800 border-purple-300";
      case "Return":
        return "bg-gray-100 text-gray-800 border-gray-300";
      case "Customs":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      default:
        return "bg-blue-100 text-blue-800 border-blue-300";
    }
  };

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={onCancel}
        className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back
      </Button>

      {/* Form Card */}
      <Card className="p-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
            <Package className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-gray-900">Add New Package</h3>
            <p className="text-gray-600">Register a new package into the tracking system</p>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {/* Tracking Number */}
            <div>
              <Label htmlFor="trackingNumber" className="text-gray-700 mb-2 block">
                Tracking Number <span className="text-red-500">*</span>
              </Label>
              <Input
                id="trackingNumber"
                type="text"
                placeholder="e.g., GY123456789"
                value={formData.trackingNumber}
                onChange={(e) => handleInputChange("trackingNumber", e.target.value)}
                className="h-11 border-2"
                required
              />
              <p className="text-xs text-gray-500 mt-1">Must be unique in the system</p>
            </div>

            {/* Branch */}
            <div>
              <Label htmlFor="branch" className="text-gray-700 mb-2 block">
                Branch <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.branch}
                onValueChange={(value) => handleInputChange("branch", value)}
                required
              >
                <SelectTrigger id="branch" className="h-11 border-2">
                  <SelectValue placeholder="Select branch..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Georgetown Central">Georgetown Central</SelectItem>
                  <SelectItem value="Diamond">Diamond</SelectItem>
                  <SelectItem value="New Amsterdam">New Amsterdam</SelectItem>
                  <SelectItem value="Linden">Linden</SelectItem>
                  <SelectItem value="Anna Regina">Anna Regina</SelectItem>
                  <SelectItem value="Bartica">Bartica</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Sender Name */}
            <div>
              <Label htmlFor="senderName" className="text-gray-700 mb-2 block">
                Sender Name <span className="text-red-500">*</span>
              </Label>
              <Input
                id="senderName"
                type="text"
                placeholder="e.g., Amazon Fulfillment Center"
                value={formData.senderName}
                onChange={(e) => handleInputChange("senderName", e.target.value)}
                className="h-11 border-2"
                required
              />
            </div>

            {/* Origin Country */}
            <div>
              <Label htmlFor="originCountry" className="text-gray-700 mb-2 block">
                Origin Country <span className="text-red-500">*</span>
              </Label>
              <Input
                id="originCountry"
                type="text"
                placeholder="e.g., United States"
                value={formData.originCountry}
                onChange={(e) => handleInputChange("originCountry", e.target.value)}
                className="h-11 border-2"
                required
              />
            </div>

            {/* Receiver Name */}
            <div>
              <Label htmlFor="receiverName" className="text-gray-700 mb-2 block">
                Receiver Name <span className="text-red-500">*</span>
              </Label>
              <Input
                id="receiverName"
                type="text"
                placeholder="e.g., John Smith"
                value={formData.receiverName}
                onChange={(e) => handleInputChange("receiverName", e.target.value)}
                className="h-11 border-2"
                required
              />
            </div>

            {/* Receiver Phone */}
            <div>
              <Label htmlFor="receiverPhone" className="text-gray-700 mb-2 block">
                Receiver Phone <span className="text-red-500">*</span>
              </Label>
              <Input
                id="receiverPhone"
                type="tel"
                placeholder="e.g., +592-222-3456"
                value={formData.receiverPhone}
                onChange={(e) => handleInputChange("receiverPhone", e.target.value)}
                className="h-11 border-2"
                required
              />
            </div>

            {/* Destination Address - Full Width */}
            <div className="md:col-span-2">
              <Label htmlFor="destinationAddress" className="text-gray-700 mb-2 block">
                Destination Address <span className="text-red-500">*</span>
              </Label>
              <Input
                id="destinationAddress"
                type="text"
                placeholder="e.g., 123 Main Street, Georgetown, Guyana"
                value={formData.destinationAddress}
                onChange={(e) => handleInputChange("destinationAddress", e.target.value)}
                className="h-11 border-2"
                required
              />
            </div>

            {/* Package Type */}
            <div>
              <Label htmlFor="packageType" className="text-gray-700 mb-2 block">
                Package Type <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.packageType}
                onValueChange={(value) => handleInputChange("packageType", value)}
                required
              >
                <SelectTrigger id="packageType" className="h-11 border-2">
                  <SelectValue placeholder="Select package type..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Document">Document</SelectItem>
                  <SelectItem value="Parcel">Parcel</SelectItem>
                  <SelectItem value="Box">Box</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Weight */}
            <div>
              <Label htmlFor="weight" className="text-gray-700 mb-2 block">
                Weight <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Input
                  id="weight"
                  type="text"
                  placeholder="e.g., 2.5"
                  value={formData.weight}
                  onChange={(e) => handleInputChange("weight", e.target.value)}
                  className="h-11 border-2 pr-12"
                  required
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
                  kg
                </span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-gray-200">
            <Button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white h-12 px-8"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Creating Package...
                </span>
              ) : (
                <>
                  <Package className="w-4 h-4 mr-2" />
                  Create Package
                </>
              )}
            </Button>
            <button
              type="button"
              onClick={onCancel}
              className="text-gray-600 hover:text-gray-900 hover:underline transition-colors h-12 px-4"
            >
              Cancel
            </button>
          </div>
        </form>
      </Card>

      {/* Help Card */}
      <Card className="p-6 bg-blue-50 border-blue-200">
        <h4 className="text-gray-900 mb-2">Package Registration Guidelines</h4>
        <ul className="space-y-1 text-sm text-gray-700">
          <li>• Ensure the tracking number is unique and follows the format: GY + 9 digits</li>
          <li>• Verify receiver contact information before submitting</li>
          <li>• Weight should be entered in kilograms (kg)</li>
          <li>• Double-check the destination address for accuracy</li>
        </ul>
      </Card>

      {/* Label Generation Card */}
      <Card className="p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
            <Tag className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <h3 className="text-gray-900">Shipping Label</h3>
            <p className="text-gray-600">Generate and print shipping labels for this package</p>
          </div>
        </div>

        {/* Label Type Selector */}
        <div className="mb-6">
          <Label htmlFor="labelType" className="text-gray-700 mb-2 block">
            Label Type
          </Label>
          <Select
            value={labelType}
            onValueChange={setLabelType}
          >
            <SelectTrigger id="labelType" className="h-11 border-2 max-w-md">
              <SelectValue placeholder="Select label type..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Standard">Standard</SelectItem>
              <SelectItem value="Express">Express</SelectItem>
              <SelectItem value="Fragile">Fragile</SelectItem>
              <SelectItem value="Heavy">Heavy</SelectItem>
              <SelectItem value="Return">Return</SelectItem>
              <SelectItem value="Customs">Customs</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Generate Label Button */}
        <div className="mb-6">
          <Button
            onClick={handleGenerateLabel}
            className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-6"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Generate Label
          </Button>
        </div>

        {/* Label Preview Card */}
        {labelGenerated && (
          <div className="space-y-6">
            {/* Preview Card */}
            <div className="border-2 border-gray-300 rounded-lg bg-white p-8 relative overflow-hidden">
              {/* GPOC Header */}
              <div className="flex items-center justify-between mb-6 pb-4 border-b-2 border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                    <Package className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-gray-900">GPOC</h2>
                    <p className="text-sm text-gray-600">Guyana Post Office Corporation</p>
                  </div>
                </div>
                <div className={`px-4 py-2 rounded-lg border-2 ${getLabelTypeColor()}`}>
                  <span className="uppercase tracking-wide">{labelType}</span>
                </div>
              </div>

              {/* Tracking Number - Large */}
              <div className="mb-6 bg-gray-50 p-4 rounded-lg border border-gray-200">
                <p className="text-sm text-gray-600 mb-1">Tracking Number</p>
                <h1 className="text-gray-900 tracking-wider">{formData.trackingNumber || "N/A"}</h1>
              </div>

              {/* Two Column Layout */}
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                {/* From Section */}
                <div className="space-y-3">
                  <div className="bg-blue-50 px-3 py-1.5 rounded inline-block">
                    <span className="text-sm text-blue-900">FROM</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Sender Name</p>
                    <p className="text-gray-900">{formData.senderName || "N/A"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Origin Country</p>
                    <p className="text-gray-900">{formData.originCountry || "N/A"}</p>
                  </div>
                </div>

                {/* To Section */}
                <div className="space-y-3">
                  <div className="bg-green-50 px-3 py-1.5 rounded inline-block">
                    <span className="text-sm text-green-900">TO</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Receiver Name</p>
                    <p className="text-gray-900">{formData.receiverName || "N/A"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Destination Address</p>
                    <p className="text-gray-900">{formData.destinationAddress || "N/A"}</p>
                  </div>
                </div>
              </div>

              {/* Package Details Row */}
              <div className="grid grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-xs text-gray-600 mb-1">Branch</p>
                  <p className="text-gray-900">{formData.branch || "N/A"}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">Weight</p>
                  <p className="text-gray-900">{formData.weight ? `${formData.weight} kg` : "N/A"}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">Package Type</p>
                  <p className="text-gray-900">{formData.packageType || "N/A"}</p>
                </div>
              </div>

              {/* QR Code Section */}
              <div className="flex items-center justify-center pt-4 border-t-2 border-gray-200">
                <div className="text-center">
                  <QRCodeSVG
                    value={formData.trackingNumber || "NO-TRACKING-NUMBER"}
                    size={120}
                    level="H"
                    includeMargin={true}
                    className="mx-auto mb-2"
                  />
                  <p className="text-xs text-gray-500">Scan to track package</p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4">
              <Button
                onClick={handleDownloadPDF}
                className="bg-red-600 hover:bg-red-700 text-white h-11 px-6"
              >
                <FileDown className="w-4 h-4 mr-2" />
                Download Label (PDF)
              </Button>
              <Button
                onClick={handlePrintLabel}
                className="bg-gray-600 hover:bg-gray-700 text-white h-11 px-6"
              >
                <Printer className="w-4 h-4 mr-2" />
                Print Label
              </Button>
            </div>
          </div>
        )}

        {/* Instruction when no label generated */}
        {!labelGenerated && (
          <div className="text-center py-8 text-gray-500">
            <Tag className="w-12 h-12 mx-auto mb-3 text-gray-400" />
            <p>Fill in the package details above and click "Generate Label" to create a shipping label.</p>
          </div>
        )}
      </Card>
    </div>
  );
}