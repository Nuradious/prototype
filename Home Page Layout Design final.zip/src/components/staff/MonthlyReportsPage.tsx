import { useState } from "react";
import { Calendar, TrendingUp, TrendingDown, Package, CheckCircle, Truck, Clock, BarChart3 } from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Label } from "../ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";

interface MonthlyReportsPageProps {
  onViewDetails?: () => void;
}

export function MonthlyReportsPage({ onViewDetails }: MonthlyReportsPageProps) {
  const [selectedMonth, setSelectedMonth] = useState("11");
  const [selectedYear, setSelectedYear] = useState("2024");
  const [selectedBranch, setSelectedBranch] = useState("all");

  // Summary data
  const summaryData = [
    {
      title: "Total Packages",
      value: 1247,
      change: 12.5,
      isPositive: true,
      icon: Package,
      color: "blue",
    },
    {
      title: "Delivered",
      value: 892,
      change: 8.3,
      isPositive: true,
      icon: CheckCircle,
      color: "green",
    },
    {
      title: "In-Transit",
      value: 284,
      change: -5.2,
      isPositive: false,
      icon: Truck,
      color: "orange",
    },
    {
      title: "Delayed",
      value: 71,
      change: -15.8,
      isPositive: true,
      icon: Clock,
      color: "red",
    },
  ];

  const handleGenerateReport = () => {
    console.log("Generating report for:", {
      month: selectedMonth,
      year: selectedYear,
      branch: selectedBranch,
    });
    // In a real app, this would fetch new data from the API
  };

  return (
    <div className="space-y-6">
      {/* Filters Section */}
      <Card className="p-6">
        <div className="flex flex-wrap items-end gap-4">
          {/* Month Selector */}
          <div className="flex-1 min-w-[180px]">
            <Label htmlFor="month" className="text-gray-700 mb-2 block">
              Month
            </Label>
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger id="month" className="h-11 border-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">January</SelectItem>
                <SelectItem value="2">February</SelectItem>
                <SelectItem value="3">March</SelectItem>
                <SelectItem value="4">April</SelectItem>
                <SelectItem value="5">May</SelectItem>
                <SelectItem value="6">June</SelectItem>
                <SelectItem value="7">July</SelectItem>
                <SelectItem value="8">August</SelectItem>
                <SelectItem value="9">September</SelectItem>
                <SelectItem value="10">October</SelectItem>
                <SelectItem value="11">November</SelectItem>
                <SelectItem value="12">December</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Year Selector */}
          <div className="flex-1 min-w-[140px]">
            <Label htmlFor="year" className="text-gray-700 mb-2 block">
              Year
            </Label>
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger id="year" className="h-11 border-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
                <SelectItem value="2022">2022</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Branch Selector */}
          <div className="flex-1 min-w-[200px]">
            <Label htmlFor="branch" className="text-gray-700 mb-2 block">
              Branch
            </Label>
            <Select value={selectedBranch} onValueChange={setSelectedBranch}>
              <SelectTrigger id="branch" className="h-11 border-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Branches</SelectItem>
                <SelectItem value="georgetown">Georgetown Central</SelectItem>
                <SelectItem value="diamond">Diamond</SelectItem>
                <SelectItem value="newamsterdam">New Amsterdam</SelectItem>
                <SelectItem value="linden">Linden</SelectItem>
                <SelectItem value="annaregina">Anna Regina</SelectItem>
                <SelectItem value="bartica">Bartica</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Generate Report Button */}
          <Button
            onClick={handleGenerateReport}
            className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-6"
          >
            <Calendar className="w-4 h-4 mr-2" />
            Generate Report
          </Button>
        </div>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {summaryData.map((item, index) => {
          const Icon = item.icon;
          const colorClasses = {
            blue: { bg: "bg-blue-100", text: "text-blue-600", border: "border-l-blue-600" },
            green: { bg: "bg-green-100", text: "text-green-600", border: "border-l-green-600" },
            orange: { bg: "bg-orange-100", text: "text-orange-600", border: "border-l-orange-600" },
            red: { bg: "bg-red-100", text: "text-red-600", border: "border-l-red-600" },
          }[item.color];

          return (
            <Card key={index} className={`p-6 border-l-4 ${colorClasses.border}`}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <p className="text-sm text-gray-600 mb-1">{item.title}</p>
                  <h2 className="text-gray-900">{item.value.toLocaleString()}</h2>
                </div>
                <div className={`w-12 h-12 ${colorClasses.bg} rounded-lg flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 ${colorClasses.text}`} />
                </div>
              </div>
              <div className="flex items-center gap-1 text-sm">
                {item.isPositive ? (
                  <>
                    <TrendingUp className="w-4 h-4 text-green-600" />
                    <span className="text-green-600">{Math.abs(item.change)}%</span>
                  </>
                ) : (
                  <>
                    <TrendingDown className="w-4 h-4 text-red-600" />
                    <span className="text-red-600">{Math.abs(item.change)}%</span>
                  </>
                )}
                <span className="text-gray-600">vs last month</span>
              </div>
            </Card>
          );
        })}
      </div>

      {/* View Detailed Analytics Button */}
      <Card className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-gray-900 mb-1">Detailed Analytics</h3>
            <p className="text-sm text-gray-600">
              View comprehensive charts, graphs, and visual breakdowns of your monthly data
            </p>
          </div>
          <Button
            onClick={onViewDetails}
            className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-6"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            View Detailed Analytics
          </Button>
        </div>
      </Card>
    </div>
  );
}
