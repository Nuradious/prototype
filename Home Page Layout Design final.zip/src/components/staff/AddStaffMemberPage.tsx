import { useState, FormEvent } from "react";
import { ArrowLeft, User, Mail, Phone, Briefcase, Building2, Shield, Key, Check, X as XIcon, AlertCircle } from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";

interface AddStaffMemberPageProps {
  onBack: () => void;
}

export function AddStaffMemberPage({ onBack }: AddStaffMemberPageProps) {
  const [showSuccessBanner, setShowSuccessBanner] = useState(false);
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    role: "",
    branch: "",
    status: "Active",
    staffId: "",
    password: "",
    confirmPassword: "",
  });

  // Auto-generate Staff ID when role or branch changes
  const generateStaffId = () => {
    const roleCode = formData.role ? formData.role.substring(0, 2).toUpperCase() : "XX";
    const branchCode = formData.branch ? formData.branch.substring(0, 3).toUpperCase() : "XXX";
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    return `${roleCode}-${branchCode}-${randomNum}`;
  };

  const handleGenerateStaffId = () => {
    if (formData.role && formData.branch) {
      setFormData({ ...formData, staffId: generateStaffId() });
    }
  };

  const validateForm = () => {
    const errors: { [key: string]: string } = {};

    // Full Name validation
    if (!formData.fullName.trim()) {
      errors.fullName = "Full name is required";
    } else if (formData.fullName.trim().length < 3) {
      errors.fullName = "Name must be at least 3 characters";
    }

    // Email validation
    if (!formData.email.trim()) {
      errors.email = "Email address is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = "Please enter a valid email address";
    }

    // Phone validation
    if (!formData.phone.trim()) {
      errors.phone = "Phone number is required";
    } else if (!/^\+?[\d\s-()]+$/.test(formData.phone)) {
      errors.phone = "Please enter a valid phone number";
    }

    // Role validation
    if (!formData.role) {
      errors.role = "Please select a role";
    }

    // Branch validation
    if (!formData.branch) {
      errors.branch = "Please select a branch";
    }

    // Staff ID validation
    if (!formData.staffId.trim()) {
      errors.staffId = "Staff ID is required";
    }

    // Password validation
    if (!formData.password) {
      errors.password = "Password is required";
    } else if (formData.password.length < 8) {
      errors.password = "Password must be at least 8 characters";
    }

    // Confirm Password validation
    if (!formData.confirmPassword) {
      errors.confirmPassword = "Please confirm password";
    } else if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      console.log("Creating staff member:", formData);
      
      // Show success banner
      setShowSuccessBanner(true);
      
      // Reset form
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        role: "",
        branch: "",
        status: "Active",
        staffId: "",
        password: "",
        confirmPassword: "",
      });
      setFormErrors({});

      // Auto-hide banner and navigate back after 3 seconds
      setTimeout(() => {
        setShowSuccessBanner(false);
        onBack();
      }, 3000);
    }
  };

  const handleCancel = () => {
    // Reset form and go back
    setFormData({
      fullName: "",
      email: "",
      phone: "",
      role: "",
      branch: "",
      status: "Active",
      staffId: "",
      password: "",
      confirmPassword: "",
    });
    setFormErrors({});
    onBack();
  };

  return (
    <div className="space-y-6">
      {/* Success Banner */}
      {showSuccessBanner && (
        <Card className="p-4 bg-green-50 border-green-200 animate-in slide-in-from-top">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <Check className="w-5 h-5 text-green-600" />
            </div>
            <div className="flex-1">
              <h4 className="text-green-900">Success!</h4>
              <p className="text-sm text-green-700">Staff member added successfully. Redirecting...</p>
            </div>
            <button
              onClick={() => setShowSuccessBanner(false)}
              className="text-green-600 hover:text-green-700"
            >
              <XIcon className="w-5 h-5" />
            </button>
          </div>
        </Card>
      )}

      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={onBack}
        className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Staff Management
      </Button>

      {/* Form Card */}
      <Card className="p-8">
        <div className="mb-8">
          <h3 className="text-gray-900 mb-2">Staff Member Information</h3>
          <p className="text-sm text-gray-600">
            Fill in the details below to add a new staff member to the system.
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Form Fields - Two Column Grid */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {/* Full Name */}
            <div>
              <Label htmlFor="fullName" className="text-gray-700 mb-2 block">
                Full Name <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="fullName"
                  type="text"
                  placeholder="e.g., John Smith"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className={`pl-10 h-11 border-2 ${formErrors.fullName ? "border-red-300 focus:border-red-500" : ""}`}
                />
              </div>
              {formErrors.fullName && (
                <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {formErrors.fullName}
                </p>
              )}
            </div>

            {/* Email Address */}
            <div>
              <Label htmlFor="email" className="text-gray-700 mb-2 block">
                Email Address <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="e.g., john.smith@guyanapost.gy"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className={`pl-10 h-11 border-2 ${formErrors.email ? "border-red-300 focus:border-red-500" : ""}`}
                />
              </div>
              {formErrors.email && (
                <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {formErrors.email}
                </p>
              )}
            </div>

            {/* Phone Number */}
            <div>
              <Label htmlFor="phone" className="text-gray-700 mb-2 block">
                Phone Number <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="phone"
                  type="tel"
                  placeholder="e.g., +592-222-3456"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className={`pl-10 h-11 border-2 ${formErrors.phone ? "border-red-300 focus:border-red-500" : ""}`}
                />
              </div>
              {formErrors.phone && (
                <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {formErrors.phone}
                </p>
              )}
            </div>

            {/* Role */}
            <div>
              <Label htmlFor="role" className="text-gray-700 mb-2 block">
                Role <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 z-10 pointer-events-none" />
                <Select
                  value={formData.role}
                  onValueChange={(value) => {
                    setFormData({ ...formData, role: value });
                  }}
                >
                  <SelectTrigger
                    id="role"
                    className={`h-11 border-2 pl-10 ${formErrors.role ? "border-red-300 focus:border-red-500" : ""}`}
                  >
                    <SelectValue placeholder="Select role..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Delivery Driver">Delivery Driver</SelectItem>
                    <SelectItem value="Supervisor">Supervisor</SelectItem>
                    <SelectItem value="Branch Manager">Branch Manager</SelectItem>
                    <SelectItem value="Customs Officer">Customs Officer</SelectItem>
                    <SelectItem value="Sorting Clerk">Sorting Clerk</SelectItem>
                    <SelectItem value="Delivery Manager">Delivery Manager</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formErrors.role && (
                <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {formErrors.role}
                </p>
              )}
            </div>

            {/* Branch */}
            <div>
              <Label htmlFor="branch" className="text-gray-700 mb-2 block">
                Branch <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 z-10 pointer-events-none" />
                <Select
                  value={formData.branch}
                  onValueChange={(value) => {
                    setFormData({ ...formData, branch: value });
                  }}
                >
                  <SelectTrigger
                    id="branch"
                    className={`h-11 border-2 pl-10 ${formErrors.branch ? "border-red-300 focus:border-red-500" : ""}`}
                  >
                    <SelectValue placeholder="Select branch..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Georgetown">Georgetown Central</SelectItem>
                    <SelectItem value="Diamond">Diamond</SelectItem>
                    <SelectItem value="New Amsterdam">New Amsterdam</SelectItem>
                    <SelectItem value="Linden">Linden</SelectItem>
                    <SelectItem value="Anna Regina">Anna Regina</SelectItem>
                    <SelectItem value="Bartica">Bartica</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formErrors.branch && (
                <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {formErrors.branch}
                </p>
              )}
            </div>

            {/* Status */}
            <div>
              <Label htmlFor="status" className="text-gray-700 mb-2 block">
                Status <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 z-10 pointer-events-none" />
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({ ...formData, status: value })}
                >
                  <SelectTrigger id="status" className="h-11 border-2 pl-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Staff ID */}
            <div>
              <Label htmlFor="staffId" className="text-gray-700 mb-2 block">
                Staff ID <span className="text-red-500">*</span>
              </Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="staffId"
                    type="text"
                    placeholder="e.g., DD-GEO-1234"
                    value={formData.staffId}
                    onChange={(e) => setFormData({ ...formData, staffId: e.target.value })}
                    className={`pl-10 h-11 border-2 ${formErrors.staffId ? "border-red-300 focus:border-red-500" : ""}`}
                  />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleGenerateStaffId}
                  className="h-11 border-2 px-4 whitespace-nowrap"
                  disabled={!formData.role || !formData.branch}
                >
                  Generate
                </Button>
              </div>
              {formErrors.staffId && (
                <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {formErrors.staffId}
                </p>
              )}
              <p className="text-xs text-gray-500 mt-1">
                Select role and branch to auto-generate an ID
              </p>
            </div>

            {/* Password */}
            <div>
              <Label htmlFor="password" className="text-gray-700 mb-2 block">
                Password <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className={`pl-10 h-11 border-2 ${formErrors.password ? "border-red-300 focus:border-red-500" : ""}`}
                />
              </div>
              {formErrors.password && (
                <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {formErrors.password}
                </p>
              )}
              <p className="text-xs text-gray-500 mt-1">
                Must be at least 8 characters
              </p>
            </div>

            {/* Confirm Password */}
            <div>
              <Label htmlFor="confirmPassword" className="text-gray-700 mb-2 block">
                Confirm Password <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Confirm password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className={`pl-10 h-11 border-2 ${formErrors.confirmPassword ? "border-red-300 focus:border-red-500" : ""}`}
                />
              </div>
              {formErrors.confirmPassword && (
                <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {formErrors.confirmPassword}
                </p>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-4 pt-6 border-t border-gray-200">
            <Button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-8"
            >
              <User className="w-4 h-4 mr-2" />
              Create Staff Member
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
              className="border-2 h-11 px-8"
            >
              Cancel
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
