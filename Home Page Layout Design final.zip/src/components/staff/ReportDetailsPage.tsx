import { useState } from "react";
import { ArrowLeft, FileDown, Printer, FileSpreadsheet } from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Textarea } from "../ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface ReportDetailsPageProps {
  onBack: () => void;
}

export function ReportDetailsPage({ onBack }: ReportDetailsPageProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [notes, setNotes] = useState("");
  const itemsPerPage = 10;

  // Weekly packages data for bar chart
  const weeklyData = [
    { week: "Week 1", packages: 298 },
    { week: "Week 2", packages: 334 },
    { week: "Week 3", packages: 312 },
    { week: "Week 4", packages: 303 },
  ];

  // Status breakdown data for pie chart
  const statusData = [
    { name: "Delivered", value: 892, color: "#10b981" },
    { name: "In Transit", value: 284, color: "#f59e0b" },
    { name: "Delayed", value: 71, color: "#ef4444" },
    { name: "Returned", value: 0, color: "#6b7280" },
  ];

  // Mock table data
  const tableData = [
    {
      trackingNumber: "GPO-2024-15478",
      customerName: "Sarah Johnson",
      branch: "Georgetown Central",
      status: "Delivered",
      deliveryOption: "Home",
      dateCreated: "2024-11-02",
      dateDelivered: "2024-11-04",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15479",
      customerName: "Michael Chen",
      branch: "Diamond",
      status: "Delivered",
      deliveryOption: "Pickup",
      dateCreated: "2024-11-03",
      dateDelivered: "2024-11-05",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15480",
      customerName: "Amanda Williams",
      branch: "New Amsterdam",
      status: "In Transit",
      deliveryOption: "Home",
      dateCreated: "2024-11-05",
      dateDelivered: "-",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15481",
      customerName: "David Kumar",
      branch: "Georgetown Central",
      status: "Delivered",
      deliveryOption: "Home",
      dateCreated: "2024-11-01",
      dateDelivered: "2024-11-03",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15482",
      customerName: "Jennifer Martinez",
      branch: "Linden",
      status: "Delayed",
      deliveryOption: "Home",
      dateCreated: "2024-11-04",
      dateDelivered: "-",
      delayed: "Yes",
    },
    {
      trackingNumber: "GPO-2024-15483",
      customerName: "Robert Taylor",
      branch: "Diamond",
      status: "Delivered",
      deliveryOption: "Pickup",
      dateCreated: "2024-11-06",
      dateDelivered: "2024-11-08",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15484",
      customerName: "Lisa Anderson",
      branch: "Georgetown Central",
      status: "In Transit",
      deliveryOption: "Home",
      dateCreated: "2024-11-08",
      dateDelivered: "-",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15485",
      customerName: "Kevin Brown",
      branch: "Anna Regina",
      status: "Delivered",
      deliveryOption: "Home",
      dateCreated: "2024-11-07",
      dateDelivered: "2024-11-10",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15486",
      customerName: "Maria Garcia",
      branch: "Bartica",
      status: "Delayed",
      deliveryOption: "Home",
      dateCreated: "2024-11-05",
      dateDelivered: "-",
      delayed: "Yes",
    },
    {
      trackingNumber: "GPO-2024-15487",
      customerName: "James Wilson",
      branch: "Georgetown Central",
      status: "Delivered",
      deliveryOption: "Pickup",
      dateCreated: "2024-11-09",
      dateDelivered: "2024-11-11",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15488",
      customerName: "Emily Davis",
      branch: "New Amsterdam",
      status: "In Transit",
      deliveryOption: "Home",
      dateCreated: "2024-11-10",
      dateDelivered: "-",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15489",
      customerName: "Christopher Lee",
      branch: "Diamond",
      status: "Delivered",
      deliveryOption: "Home",
      dateCreated: "2024-11-08",
      dateDelivered: "2024-11-12",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15490",
      customerName: "Patricia Thompson",
      branch: "Georgetown Central",
      status: "Delivered",
      deliveryOption: "Home",
      dateCreated: "2024-11-11",
      dateDelivered: "2024-11-14",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15491",
      customerName: "Daniel Rodriguez",
      branch: "Linden",
      status: "In Transit",
      deliveryOption: "Pickup",
      dateCreated: "2024-11-12",
      dateDelivered: "-",
      delayed: "No",
    },
    {
      trackingNumber: "GPO-2024-15492",
      customerName: "Michelle White",
      branch: "Georgetown Central",
      status: "Delivered",
      deliveryOption: "Home",
      dateCreated: "2024-11-10",
      dateDelivered: "2024-11-13",
      delayed: "No",
    },
  ];

  const totalPages = Math.ceil(tableData.length / itemsPerPage);
  const paginatedData = tableData.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "Delivered":
        return "bg-green-100 text-green-800 border-green-200";
      case "In Transit":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "Delayed":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const handleExportPDF = () => {
    console.log("Exporting to PDF...");
    alert("PDF export functionality would be implemented here.");
  };

  const handleExportCSV = () => {
    console.log("Exporting to CSV...");
    alert("CSV export functionality would be implemented here.");
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <div>
        <Button
          onClick={onBack}
          variant="outline"
          className="border-2"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Summary
        </Button>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bar Chart - Packages by Week */}
        <Card className="p-6">
          <h3 className="text-gray-900 mb-6">Packages by Week</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="week" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#fff",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
              <Legend />
              <Bar dataKey="packages" fill="#2563eb" name="Packages" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Pie Chart - Package Status Breakdown */}
        <Card className="p-6">
          <h3 className="text-gray-900 mb-6">Package Status Breakdown</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "#fff",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Export Tools */}
      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <h4 className="text-gray-900 mr-2">Export Options:</h4>
          <Button
            onClick={handleExportPDF}
            variant="outline"
            className="border-2 h-10"
          >
            <FileDown className="w-4 h-4 mr-2" />
            Export as PDF
          </Button>
          <Button
            onClick={handleExportCSV}
            variant="outline"
            className="border-2 h-10"
          >
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            Export as CSV
          </Button>
          <Button
            onClick={handlePrint}
            variant="outline"
            className="border-2 h-10"
          >
            <Printer className="w-4 h-4 mr-2" />
            Print Report
          </Button>
        </div>
      </Card>

      {/* Data Table Section */}
      <Card className="p-6">
        <div className="mb-6">
          <h3 className="text-gray-900 mb-1">Monthly Package Overview</h3>
          <p className="text-sm text-gray-600">
            Detailed breakdown of all packages for the selected period
          </p>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead className="text-gray-900">Tracking Number</TableHead>
                <TableHead className="text-gray-900">Customer Name</TableHead>
                <TableHead className="text-gray-900">Branch</TableHead>
                <TableHead className="text-gray-900">Status</TableHead>
                <TableHead className="text-gray-900">Delivery Option</TableHead>
                <TableHead className="text-gray-900">Date Created</TableHead>
                <TableHead className="text-gray-900">Date Delivered</TableHead>
                <TableHead className="text-gray-900">Delayed</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedData.map((row, index) => (
                <TableRow
                  key={index}
                  className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}
                >
                  <TableCell className="text-blue-600">{row.trackingNumber}</TableCell>
                  <TableCell className="text-gray-900">{row.customerName}</TableCell>
                  <TableCell className="text-gray-700">{row.branch}</TableCell>
                  <TableCell>
                    <Badge className={`border ${getStatusBadgeColor(row.status)}`}>
                      {row.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-gray-700">{row.deliveryOption}</TableCell>
                  <TableCell className="text-gray-700">{row.dateCreated}</TableCell>
                  <TableCell className="text-gray-700">{row.dateDelivered}</TableCell>
                  <TableCell>
                    <Badge
                      className={`border ${
                        row.delayed === "Yes"
                          ? "bg-red-100 text-red-800 border-red-200"
                          : "bg-gray-100 text-gray-800 border-gray-200"
                      }`}
                    >
                      {row.delayed}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between mt-6 pt-6 border-t border-gray-200">
          <p className="text-sm text-gray-600">
            Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
            {Math.min(currentPage * itemsPerPage, tableData.length)} of{" "}
            {tableData.length} entries
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              className="border-2"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              Previous
            </Button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <Button
                key={page}
                variant={currentPage === page ? "default" : "outline"}
                className={
                  currentPage === page
                    ? "bg-blue-600 text-white"
                    : "border-2"
                }
                onClick={() => setCurrentPage(page)}
              >
                {page}
              </Button>
            ))}
            <Button
              variant="outline"
              className="border-2"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              Next
            </Button>
          </div>
        </div>
      </Card>

      {/* Notes Section */}
      <Card className="p-6">
        <div className="mb-4">
          <h3 className="text-gray-900 mb-1">Internal Notes</h3>
          <p className="text-sm text-gray-600">
            Add notes about this report (not visible to customers)
          </p>
        </div>
        <Textarea
          placeholder="Enter internal notes, observations, or action items here..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="min-h-[120px] border-2 resize-none"
        />
        <div className="mt-4 flex justify-end">
          <Button
            onClick={() => console.log("Saving notes:", notes)}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Save Notes
          </Button>
        </div>
      </Card>
    </div>
  );
}
