import { useState } from "react";
import { Search, Filter, Eye, Edit, UserPlus } from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Badge } from "../ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";

const staffData = [
  {
    id: 1,
    staffId: "ST001",
    name: "Kevin Thompson",
    role: "Delivery Manager",
    branch: "Georgetown Central",
    email: "k.thompson@guyanapost.gy",
    status: "Active",
  },
  {
    id: 2,
    staffId: "ST002",
    name: "Michelle Williams",
    role: "Supervisor",
    branch: "Georgetown Central",
    email: "m.williams@guyanapost.gy",
    status: "Active",
  },
  {
    id: 3,
    staffId: "ST001",
    name: "Robert Chen",
    role: "Delivery Driver",
    branch: "Diamond",
    email: "r.chen@guyanapost.gy",
    status: "Active",
  },
  {
    id: 4,
    staffId: "ST002",
    name: "Sarah Martinez",
    role: "Supervisor",
    branch: "Georgetown",
    email: "s.martinez@guyanapost.gy",
    status: "Active",
  },
  {
    id: 5,
    staffId: "ST003",
    name: "David Kumar",
    role: "Branch Manager",
    branch: "Anna Regina",
    email: "d.kumar@guyanapost.gy",
    status: "Active",
  },
  {
    id: 6,
    staffId: "ST004",
    name: "Jennifer Ali",
    role: "Customs Officer",
    branch: "Linden",
    email: "j.ali@guyanapost.gy",
    status: "Active",
  },
  {
    id: 7,
    staffId: "ST005",
    name: "Michael Brown",
    role: "Sorting Clerk",
    branch: "Georgetown Central",
    email: "m.brown@guyanapost.gy",
    status: "Inactive",
  },
  {
    id: 8,
    staffId: "ST006",
    name: "Lisa Johnson",
    role: "Delivery Driver",
    branch: "Georgetown Central",
    email: "l.johnson@guyanapost.gy",
    status: "Inactive",
  },
  {
    id: 9,
    staffId: "ST007",
    name: "Christopher Lee",
    role: "Customer Service Rep",
    branch: "Diamond",
    email: "c.lee@guyanapost.gy",
    status: "Active",
  },
  {
    id: 10,
    staffId: "ST008",
    name: "Amanda White",
    role: "IT Support",
    branch: "Georgetown Central",
    email: "a.white@guyanapost.gy",
    status: "Active",
  },
  {
    id: 11,
    staffId: "ST009",
    name: "James Taylor",
    role: "Warehouse Manager",
    branch: "New Amsterdam",
    email: "j.taylor@guyanapost.gy",
    status: "Active",
  },
  {
    id: 12,
    staffId: "ST010",
    name: "Patricia Garcia",
    role: "Delivery Driver",
    branch: "Linden",
    email: "p.garcia@guyanapost.gy",
    status: "Inactive",
  },
];

interface StaffManagementPageProps {
  onAddStaff?: () => void;
  onEditStaff?: (staffId: string) => void;
}

export function StaffManagementPage({ onAddStaff, onEditStaff }: StaffManagementPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [branchFilter, setBranchFilter] = useState("all");

  const filteredStaff = staffData.filter((staff) => {
    const matchesSearch =
      searchQuery === "" ||
      staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.branch.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRoleFilter =
      roleFilter === "all" || staff.role.toLowerCase() === roleFilter.toLowerCase();

    const matchesBranchFilter =
      branchFilter === "all" ||
      staff.branch.toLowerCase() === branchFilter.toLowerCase();

    return matchesSearch && matchesRoleFilter && matchesBranchFilter;
  });

  const activeStaffCount = staffData.filter((s) => s.status === "Active").length;
  const inactiveStaffCount = staffData.filter((s) => s.status === "Inactive").length;

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6">
          <p className="text-sm text-gray-600 mb-1">Total Staff</p>
          <h3 className="text-gray-900">{staffData.length}</h3>
        </Card>
        <Card className="p-6">
          <p className="text-sm text-gray-600 mb-1">Active Staff</p>
          <h3 className="text-gray-900">{activeStaffCount}</h3>
        </Card>
        <Card className="p-6">
          <p className="text-sm text-gray-600 mb-1">Inactive Staff</p>
          <h3 className="text-gray-900">{inactiveStaffCount}</h3>
        </Card>
      </div>

      {/* Main Card */}
      <Card className="p-6">
        {/* Header with Search and Add Button */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Search staff by name, email, role, or branch..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-11 border-2"
              />
            </div>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-6" onClick={onAddStaff}>
            <UserPlus className="w-4 h-4 mr-2" />
            Add Staff Member
          </Button>
        </div>

        {/* Results Count */}
        <div className="mb-4 pb-4 border-b border-gray-200">
          <p className="text-sm text-gray-600">
            Showing <span className="text-gray-900">{filteredStaff.length}</span> of{" "}
            <span className="text-gray-900">{staffData.length}</span> staff members
          </p>
        </div>

        {/* Staff Table */}
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Branch</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStaff.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                    No staff members found matching your search
                  </TableCell>
                </TableRow>
              ) : (
                filteredStaff.map((staff) => (
                  <TableRow key={staff.id} className="hover:bg-gray-50">
                    <TableCell className="font-medium text-gray-900">
                      {staff.name}
                    </TableCell>
                    <TableCell className="text-gray-600">{staff.role}</TableCell>
                    <TableCell className="text-gray-600">{staff.branch}</TableCell>
                    <TableCell className="text-gray-600">{staff.email}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`${
                          staff.status === "Active"
                            ? "bg-green-100 text-green-700 border-green-200"
                            : "bg-gray-100 text-gray-700 border-gray-200"
                        } border`}
                      >
                        {staff.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                        onClick={() => onEditStaff?.(staff.id.toString())}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}