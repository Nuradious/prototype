import { useState, ReactNode } from "react";
import {
  Package,
  LayoutDashboard,
  PackagePlus,
  Users,
  Settings,
  LogOut,
  Search,
  Bell,
  User,
  ChevronRight,
  ChevronDown,
  Building2,
  FileText,
} from "lucide-react";
import { Input } from "../ui/input";
import { Badge } from "../ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";

interface DashboardLayoutProps {
  children: ReactNode;
  activeMenu: string;
  onMenuChange: (menu: string) => void;
  onLogout?: () => void;
  pageTitle: string;
  pageSubtitle?: string;
  breadcrumbs?: { label: string; onClick?: () => void }[];
}

export function DashboardLayout({
  children,
  activeMenu,
  onMenuChange,
  onLogout,
  pageTitle,
  pageSubtitle,
  breadcrumbs = [],
}: DashboardLayoutProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [notificationCount] = useState(3);

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "packages", label: "Packages", icon: Package },
    { id: "add-package", label: "Add Package", icon: PackagePlus },
    { id: "staff", label: "Staff", icon: Users },
    { id: "branches", label: "Branches", icon: Building2 },
    { id: "reports", label: "Reports", icon: FileText },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Left Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col fixed h-screen z-10">
        {/* Logo */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-gray-900">GPOC</h3>
              <p className="text-xs text-gray-500">Staff Portal</p>
            </div>
          </div>
        </div>

        {/* Menu Items */}
        <nav className="flex-1 p-4 overflow-y-auto">
          <ul className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeMenu === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => onMenuChange(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                      isActive
                        ? "bg-blue-600 text-white shadow-md"
                        : "text-gray-700 hover:bg-blue-50 hover:text-blue-700"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Logout Button */}
        <div className="p-4 border-t border-gray-200">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 transition-all duration-200"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col ml-64">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 px-8 py-4 sticky top-0 z-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex-1">
              {/* Breadcrumbs */}
              {breadcrumbs.length > 0 && (
                <nav className="flex items-center gap-2 text-sm mb-2">
                  {breadcrumbs.map((crumb, index) => (
                    <div key={index} className="flex items-center gap-2">
                      {crumb.onClick ? (
                        <button
                          onClick={crumb.onClick}
                          className="text-blue-600 hover:text-blue-700 hover:underline transition-colors"
                        >
                          {crumb.label}
                        </button>
                      ) : (
                        <span className="text-gray-500">{crumb.label}</span>
                      )}
                      {index < breadcrumbs.length - 1 && (
                        <ChevronRight className="w-4 h-4 text-gray-400" />
                      )}
                    </div>
                  ))}
                </nav>
              )}
              <div className="flex items-center gap-3">
                <h2 className="text-gray-900">Guyana Post Office Corporation</h2>
                <span className="text-gray-400">•</span>
                <h3 className="text-gray-700">{pageTitle}</h3>
              </div>
              {pageSubtitle && <p className="text-gray-600 text-sm mt-1">{pageSubtitle}</p>}
            </div>
            <div className="flex items-center gap-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search packages..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64 h-10 border-2"
                />
              </div>

              {/* Notifications */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                    <Bell className="w-5 h-5" />
                    {notificationCount > 0 && (
                      <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 bg-red-600 text-white text-xs">
                        {notificationCount}
                      </Badge>
                    )}
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <div className="p-3 border-b border-gray-200">
                    <h4 className="text-gray-900">Notifications</h4>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    <DropdownMenuItem className="p-3 flex flex-col items-start gap-1">
                      <div className="flex items-center gap-2 w-full">
                        <Badge className="bg-red-100 text-red-700">Delayed</Badge>
                        <span className="text-xs text-gray-500">2 hours ago</span>
                      </div>
                      <p className="text-sm text-gray-900">Package GY987654321 delayed at customs</p>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="p-3 flex flex-col items-start gap-1">
                      <div className="flex items-center gap-2 w-full">
                        <Badge className="bg-orange-100 text-orange-700">Exception</Badge>
                        <span className="text-xs text-gray-500">4 hours ago</span>
                      </div>
                      <p className="text-sm text-gray-900">Delivery attempt failed for GY456789123</p>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="p-3 flex flex-col items-start gap-1">
                      <div className="flex items-center gap-2 w-full">
                        <Badge className="bg-blue-100 text-blue-700">Info</Badge>
                        <span className="text-xs text-gray-500">6 hours ago</span>
                      </div>
                      <p className="text-sm text-gray-900">New batch of packages arrived at Georgetown</p>
                    </DropdownMenuItem>
                  </div>
                  <div className="p-3 border-t border-gray-200">
                    <button className="text-sm text-blue-600 hover:text-blue-700">
                      View all notifications
                    </button>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Profile Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-3 hover:bg-gray-100 p-2 rounded-lg transition-colors">
                    <div className="text-right hidden sm:block">
                      <p className="text-sm text-gray-900">Kevin Thompson</p>
                      <p className="text-xs text-gray-500">Delivery Manager</p>
                    </div>
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-full flex items-center justify-center text-white">
                      KT
                    </div>
                    <ChevronDown className="w-4 h-4 text-gray-500" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem className="cursor-pointer">
                    <User className="w-4 h-4 mr-2" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer">
                    <Settings className="w-4 h-4 mr-2" />
                    Settings
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onLogout} className="cursor-pointer text-red-600">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-8 overflow-auto">{children}</main>
      </div>
    </div>
  );
}