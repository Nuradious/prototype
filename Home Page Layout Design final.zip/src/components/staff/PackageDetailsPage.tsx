import { useState } from "react";
import {
  ArrowLeft,
  Package as PackageIcon,
  MapPin,
  Clock,
  CheckCircle,
  User,
  Home,
  Weight,
  Building2,
  QrCode,
  UserCircle,
  AlertTriangle,
  Check,
  X as XIcon,
  Calendar,
  Truck,
  Plane,
  Archive,
} from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../ui/alert-dialog";

interface PackageDetailsPageProps {
  trackingNumber: string;
  onBack: () => void;
}

const packageData = {
  trackingNumber: "GY123456789",
  status: "Out for Delivery",
  statusColor: "orange",
  deliveryOption: "Home",
  sender: {
    name: "Amazon Fulfillment Center",
    address: "Miami, FL, USA",
  },
  receiver: {
    name: "John Smith",
    phone: "+592-222-3456",
    address: "123 Main Street, Georgetown, Guyana",
  },
  weight: "2.5 kg",
  branch: "Georgetown Central",
  estimatedDelivery: "January 17, 2025",
  createdAt: "January 12, 2025 08:00 AM",
  lastUpdated: "January 16, 2025 10:30 AM",
  assignedAgent: "Kevin Thompson",
  trackingEvents: [
    {
      id: 1,
      status: "Out for Delivery",
      location: "Georgetown Central",
      timestamp: "2025-01-16 10:30 AM",
      description: "Package assigned to delivery driver Kevin Thompson",
      isCompleted: false,
      icon: Truck,
    },
    {
      id: 2,
      status: "Arrived at Facility",
      location: "Georgetown Central",
      timestamp: "2025-01-16 06:15 AM",
      description: "Package sorted and ready for delivery",
      isCompleted: true,
      icon: Building2,
    },
    {
      id: 3,
      status: "Customs Clearance Complete",
      location: "Georgetown Port",
      timestamp: "2025-01-15 02:30 PM",
      description: "All customs procedures completed",
      isCompleted: true,
      icon: CheckCircle,
    },
    {
      id: 4,
      status: "In Customs",
      location: "Georgetown Port",
      timestamp: "2025-01-15 09:00 AM",
      description: "Package undergoing customs inspection",
      isCompleted: true,
      icon: Archive,
    },
    {
      id: 5,
      status: "Arrived in Guyana",
      location: "Cheddi Jagan International Airport",
      timestamp: "2025-01-14 11:45 PM",
      description: "International shipment arrived",
      isCompleted: true,
      icon: Plane,
    },
    {
      id: 6,
      status: "In Transit",
      location: "Miami, FL, USA",
      timestamp: "2025-01-12 08:00 AM",
      description: "Package departed origin facility",
      isCompleted: true,
      icon: PackageIcon,
    },
  ],
  actionHistory: [
    {
      id: 1,
      action: "Status updated to 'Out for Delivery'",
      performedBy: "Kevin Thompson",
      timestamp: "2025-01-16 10:30 AM",
    },
    {
      id: 2,
      action: "Assigned to delivery agent",
      performedBy: "Michelle Williams",
      timestamp: "2025-01-16 10:15 AM",
    },
    {
      id: 3,
      action: "Package checked in at facility",
      performedBy: "System",
      timestamp: "2025-01-16 06:15 AM",
    },
    {
      id: 4,
      action: "Customs clearance completed",
      performedBy: "Sarah Martinez",
      timestamp: "2025-01-15 02:30 PM",
    },
  ],
};

export function PackageDetailsPage({ trackingNumber, onBack }: PackageDetailsPageProps) {
  const [newEvent, setNewEvent] = useState({
    status: "",
    location: "",
    notes: "",
    timestamp: new Date().toISOString().slice(0, 16),
  });
  const [assignedAgent, setAssignedAgent] = useState(packageData.assignedAgent);
  const [showSuccessBanner, setShowSuccessBanner] = useState(false);
  const [showDeliveredDialog, setShowDeliveredDialog] = useState(false);

  const getStatusColor = (color: string) => {
    const colors: { [key: string]: string } = {
      blue: "bg-blue-100 text-blue-700 border-blue-200",
      orange: "bg-orange-100 text-orange-700 border-orange-200",
      green: "bg-green-100 text-green-700 border-green-200",
      red: "bg-red-100 text-red-700 border-red-200",
    };
    return colors[color] || colors.blue;
  };

  const handleSaveEvent = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("New tracking event:", newEvent);
    
    // Show success banner
    setShowSuccessBanner(true);
    setTimeout(() => setShowSuccessBanner(false), 5000);
    
    // Reset form
    setNewEvent({
      status: "",
      location: "",
      notes: "",
      timestamp: new Date().toISOString().slice(0, 16),
    });
  };

  const handleMarkDelivered = () => {
    console.log("Marking package as delivered:", trackingNumber);
    setShowDeliveredDialog(false);
    setShowSuccessBanner(true);
    setTimeout(() => setShowSuccessBanner(false), 5000);
  };

  const handleResetForm = () => {
    setNewEvent({
      status: "",
      location: "",
      notes: "",
      timestamp: new Date().toISOString().slice(0, 16),
    });
  };

  return (
    <div className="space-y-6">
      {/* Success Banner */}
      {showSuccessBanner && (
        <Card className="p-4 bg-green-50 border-green-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <Check className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h4 className="text-green-900">Success!</h4>
              <p className="text-sm text-green-700">Package information updated successfully</p>
            </div>
            <button
              onClick={() => setShowSuccessBanner(false)}
              className="ml-auto text-green-600 hover:text-green-700"
            >
              <XIcon className="w-5 h-5" />
            </button>
          </div>
        </Card>
      )}

      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={onBack}
        className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Packages
      </Button>

      {/* Header Section */}
      <Card className="p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <PackageIcon className="w-8 h-8 text-blue-600" />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h3 className="text-gray-900">{packageData.trackingNumber}</h3>
                <Badge
                  variant="outline"
                  className={`${getStatusColor(packageData.statusColor)} border`}
                >
                  {packageData.status}
                </Badge>
                <Badge
                  variant="outline"
                  className={`${
                    packageData.deliveryOption === "Home"
                      ? "bg-purple-100 text-purple-700 border-purple-200"
                      : "bg-teal-100 text-teal-700 border-teal-200"
                  } border`}
                >
                  {packageData.deliveryOption}
                </Badge>
              </div>
              <div className="flex flex-col gap-1 text-sm text-gray-600">
                <p>Estimated Delivery: <span className="text-gray-900">{packageData.estimatedDelivery}</span></p>
                <p>Last Updated: <span className="text-gray-900">{packageData.lastUpdated}</span></p>
              </div>
            </div>
          </div>

          {/* QR Code / Barcode Placeholder */}
          <div className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
            <QrCode className="w-24 h-24 text-gray-400" />
            <p className="text-xs text-gray-500">Scan for quick access</p>
          </div>
        </div>

        {/* Assigned Delivery Agent */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <Label htmlFor="assignedAgent" className="text-gray-700 mb-2 block">
            Assigned Delivery Agent
          </Label>
          <Select value={assignedAgent} onValueChange={setAssignedAgent}>
            <SelectTrigger id="assignedAgent" className="h-11 border-2 max-w-md">
              <div className="flex items-center gap-2">
                <UserCircle className="w-4 h-4 text-gray-400" />
                <SelectValue />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Kevin Thompson">Kevin Thompson</SelectItem>
              <SelectItem value="Robert Chen">Robert Chen</SelectItem>
              <SelectItem value="David Kumar">David Kumar</SelectItem>
              <SelectItem value="Lisa Johnson">Lisa Johnson</SelectItem>
              <SelectItem value="Christopher Lee">Christopher Lee</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Left Column - Timeline */}
        <Card className="p-6">
          <h3 className="text-gray-900 mb-6 flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600" />
            Tracking Timeline
          </h3>

          <div className="space-y-4">
            {packageData.trackingEvents.map((event, index) => {
              const Icon = event.icon;
              return (
                <div key={event.id} className="flex gap-4">
                  {/* Timeline Line */}
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        event.isCompleted
                          ? "bg-green-100 border-2 border-green-300"
                          : "bg-orange-100 border-2 border-orange-300"
                      }`}
                    >
                      <Icon
                        className={`w-5 h-5 ${
                          event.isCompleted ? "text-green-600" : "text-orange-600"
                        }`}
                      />
                    </div>
                    {index < packageData.trackingEvents.length - 1 && (
                      <div className="w-0.5 h-full min-h-[70px] bg-gray-300 my-1"></div>
                    )}
                  </div>

                  {/* Event Content */}
                  <div className="flex-1 pb-6">
                    <div className="flex items-start justify-between mb-1">
                      <h4 className="text-gray-900">{event.status}</h4>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        <span>{event.timestamp}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">{event.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Right Column - Package Info */}
        <div className="space-y-6">
          <Card className="p-6">
            <h3 className="text-gray-900 mb-6 flex items-center gap-2">
              <PackageIcon className="w-5 h-5 text-blue-600" />
              Package Information
            </h3>

            <div className="space-y-4">
              {/* Sender */}
              <div>
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                  <User className="w-4 h-4" />
                  <span>Sender</span>
                </div>
                <p className="text-gray-900">{packageData.sender.name}</p>
                <p className="text-sm text-gray-600">{packageData.sender.address}</p>
              </div>

              <div className="border-t border-gray-200"></div>

              {/* Receiver */}
              <div>
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                  <User className="w-4 h-4" />
                  <span>Receiver</span>
                </div>
                <p className="text-gray-900">{packageData.receiver.name}</p>
                <p className="text-sm text-gray-600">{packageData.receiver.phone}</p>
                <div className="flex items-start gap-2 mt-1">
                  <Home className="w-4 h-4 text-gray-400 mt-0.5" />
                  <p className="text-sm text-gray-600">{packageData.receiver.address}</p>
                </div>
              </div>

              <div className="border-t border-gray-200"></div>

              {/* Package Details */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                    <Weight className="w-4 h-4" />
                    <span>Weight</span>
                  </div>
                  <p className="text-gray-900">{packageData.weight}</p>
                </div>
                <div>
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                    <Building2 className="w-4 h-4" />
                    <span>Branch</span>
                  </div>
                  <p className="text-gray-900">{packageData.branch}</p>
                </div>
              </div>

              <div className="border-t border-gray-200"></div>

              {/* Timestamps */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                    <Calendar className="w-4 h-4" />
                    <span>Created</span>
                  </div>
                  <p className="text-sm text-gray-900">{packageData.createdAt}</p>
                </div>
                <div>
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                    <Clock className="w-4 h-4" />
                    <span>Last Updated</span>
                  </div>
                  <p className="text-sm text-gray-900">{packageData.lastUpdated}</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Package Action History */}
          <Card className="p-6">
            <h3 className="text-gray-900 mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-600" />
              Package Action History
            </h3>

            <div className="space-y-3">
              {packageData.actionHistory.map((action) => (
                <div key={action.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">{action.action}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-xs text-gray-600">by {action.performedBy}</p>
                      <span className="text-xs text-gray-400">•</span>
                      <p className="text-xs text-gray-500">{action.timestamp}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Add Tracking Event Section */}
      <Card className="p-6">
        <h3 className="text-gray-900 mb-6">Add Tracking Event</h3>

        <form onSubmit={handleSaveEvent}>
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            {/* Status Dropdown */}
            <div>
              <Label htmlFor="status" className="text-gray-700 mb-2 block">
                Status <span className="text-red-500">*</span>
              </Label>
              <Select
                value={newEvent.status}
                onValueChange={(value) => setNewEvent({ ...newEvent, status: value })}
                required
              >
                <SelectTrigger id="status" className="h-11 border-2">
                  <SelectValue placeholder="Select status..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="In Transit">In Transit</SelectItem>
                  <SelectItem value="Arrived at Facility">Arrived at Facility</SelectItem>
                  <SelectItem value="Out for Delivery">Out for Delivery</SelectItem>
                  <SelectItem value="Delivery Attempted">Delivery Attempted</SelectItem>
                  <SelectItem value="Delivered">Delivered</SelectItem>
                  <SelectItem value="Delayed">Delayed</SelectItem>
                  <SelectItem value="Returned">Returned</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Location */}
            <div>
              <Label htmlFor="location" className="text-gray-700 mb-2 block">
                Location <span className="text-red-500">*</span>
              </Label>
              <Input
                id="location"
                type="text"
                placeholder="e.g., Georgetown Central"
                value={newEvent.location}
                onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                className="h-11 border-2"
                required
              />
            </div>

            {/* Timestamp */}
            <div>
              <Label htmlFor="timestamp" className="text-gray-700 mb-2 block">
                Timestamp <span className="text-red-500">*</span>
              </Label>
              <Input
                id="timestamp"
                type="datetime-local"
                value={newEvent.timestamp}
                onChange={(e) => setNewEvent({ ...newEvent, timestamp: e.target.value })}
                className="h-11 border-2"
                required
              />
            </div>

            {/* Notes */}
            <div>
              <Label htmlFor="notes" className="text-gray-700 mb-2 block">
                Notes / Description
              </Label>
              <Textarea
                id="notes"
                placeholder="Optional additional details..."
                value={newEvent.notes}
                onChange={(e) => setNewEvent({ ...newEvent, notes: e.target.value })}
                className="border-2 resize-none"
                rows={3}
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-6"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Save Event
            </Button>
            <Button
              type="button"
              onClick={() => setShowDeliveredDialog(true)}
              className="bg-green-600 hover:bg-green-700 text-white h-11 px-6"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Mark as Delivered
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleResetForm}
              className="border-2 h-11 px-6"
            >
              Reset
            </Button>
          </div>
        </form>
      </Card>

      {/* Mark as Delivered Confirmation Dialog */}
      <AlertDialog open={showDeliveredDialog} onOpenChange={setShowDeliveredDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              Mark Package as Delivered?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to mark package <strong>{trackingNumber}</strong> as delivered? 
              This action will close the package and notify the customer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleMarkDelivered}
              className="bg-green-600 hover:bg-green-700"
            >
              Confirm Delivery
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
