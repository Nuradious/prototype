import { useState } from "react";
import { Building2, MapPin, Phone, Mail, Users, Package, Search, Edit } from "lucide-react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Badge } from "../ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";

interface BranchesPageProps {
  onEditBranch?: (branchId: number) => void;
}

const branchesData = [
  {
    id: 1,
    name: "Georgetown Central",
    address: "Robb Street, Georgetown",
    phone: "+592-226-4211",
    email: "georgetown@guyanapost.gy",
    manager: "Michelle Williams",
    staffCount: 24,
    packageCount: 156,
    status: "Active",
  },
  {
    id: 2,
    name: "Diamond",
    address: "Diamond, East Bank Demerara",
    phone: "+592-265-3456",
    email: "diamond@guyanapost.gy",
    manager: "Robert Chen",
    staffCount: 12,
    packageCount: 78,
    status: "Active",
  },
  {
    id: 3,
    name: "New Amsterdam",
    address: "Main Street, New Amsterdam",
    phone: "+592-333-2211",
    email: "newamsterdam@guyanapost.gy",
    manager: "James Taylor",
    staffCount: 15,
    packageCount: 92,
    status: "Active",
  },
  {
    id: 4,
    name: "Linden",
    address: "Mackenzie, Linden",
    phone: "+592-444-5678",
    email: "linden@guyanapost.gy",
    manager: "Jennifer Ali",
    staffCount: 10,
    packageCount: 45,
    status: "Active",
  },
  {
    id: 5,
    name: "Anna Regina",
    address: "Anna Regina, Essequibo Coast",
    phone: "+592-771-2345",
    email: "annaregina@guyanapost.gy",
    manager: "David Kumar",
    staffCount: 8,
    packageCount: 34,
    status: "Active",
  },
  {
    id: 6,
    name: "Bartica",
    address: "First Avenue, Bartica",
    phone: "+592-455-1234",
    email: "bartica@guyanapost.gy",
    manager: "Christopher Lee",
    staffCount: 6,
    packageCount: 21,
    status: "Active",
  },
];

export function BranchesPage({ onEditBranch }: BranchesPageProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredBranches = branchesData.filter((branch) => {
    const matchesSearch =
      searchQuery === "" ||
      branch.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      branch.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      branch.manager.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesSearch;
  });

  const totalStaff = branchesData.reduce((sum, branch) => sum + branch.staffCount, 0);
  const totalPackages = branchesData.reduce((sum, branch) => sum + branch.packageCount, 0);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h2 className="text-gray-900 mb-2">Post Office Branches</h2>
        <p className="text-gray-600">
          View and manage all Guyana Post Office Corporation branch locations across the country.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Building2 className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <h3 className="text-gray-900">{branchesData.length}</h3>
          <p className="text-sm text-gray-600">Total Branches</p>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-gray-900">{totalStaff}</h3>
          <p className="text-sm text-gray-600">Total Staff</p>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Package className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <h3 className="text-gray-900">{totalPackages}</h3>
          <p className="text-sm text-gray-600">Active Packages</p>
        </Card>
      </div>

      {/* Main Card */}
      <Card className="p-6">
        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search branches by name, location, or manager..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-11 border-2"
            />
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-4 pb-4 border-b border-gray-200">
          <p className="text-sm text-gray-600">
            Showing <span className="text-gray-900">{filteredBranches.length}</span> of{" "}
            <span className="text-gray-900">{branchesData.length}</span> branches
          </p>
        </div>

        {/* Branches Table */}
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>Branch Name</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Manager</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Staff</TableHead>
                <TableHead>Packages</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBranches.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                    No branches found matching your search
                  </TableCell>
                </TableRow>
              ) : (
                filteredBranches.map((branch, index) => (
                  <TableRow 
                    key={branch.id} 
                    className={`hover:bg-blue-50 transition-colors ${
                      index % 2 === 0 ? "bg-white" : "bg-gray-50"
                    }`}
                  >
                    <TableCell className="font-medium text-gray-900">
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-blue-600" />
                        {branch.name}
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-600">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        <span className="text-sm">{branch.address}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-600">{branch.manager}</TableCell>
                    <TableCell className="text-gray-600 text-sm">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1">
                          <Phone className="w-3 h-3 text-gray-400" />
                          <span>{branch.phone}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Mail className="w-3 h-3 text-gray-400" />
                          <span>{branch.email}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-200">
                        {branch.staffCount}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-orange-100 text-orange-700 border-orange-200">
                        {branch.packageCount}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className="bg-green-100 text-green-700 border-green-200 border"
                      >
                        {branch.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                        onClick={() => onEditBranch?.(branch.id)}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}