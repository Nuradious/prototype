import { useState } from "react";
import { Package, Lock, Mail, Eye, EyeOff } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card } from "./ui/card";

interface StaffLoginProps {
  onBack?: () => void;
  onLoginSuccess?: () => void;
}

export function StaffLogin({ onBack, onLoginSuccess }: StaffLoginProps) {
  const [credentials, setCredentials] = useState({
    emailOrStaffId: "",
    password: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate login process
    setTimeout(() => {
      console.log("Login attempt:", credentials);
      setIsLoading(false);
      // Call the success callback to navigate to dashboard
      if (onLoginSuccess) {
        onLoginSuccess();
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-gray-50 flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-md">
        {/* Back to Main Site Link */}
        {onBack && (
          <button
            onClick={onBack}
            className="text-sm text-gray-600 hover:text-blue-600 mb-6 transition-colors"
          >
            ← Back to Main Site
          </button>
        )}

        {/* Login Card */}
        <Card className="p-8 shadow-xl border-t-4 border-t-blue-600">
          {/* Logo and Title */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Package className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-gray-900 mb-2">Guyana Post Office</h2>
            <div className="inline-block px-4 py-1.5 bg-red-100 rounded-full">
              <p className="text-sm text-red-700">Staff Portal</p>
            </div>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email/Staff ID Field */}
            <div>
              <Label htmlFor="emailOrStaffId" className="text-gray-700 mb-2 block">
                Email or Staff ID
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  id="emailOrStaffId"
                  type="text"
                  placeholder="staff@guyanapost.gy or GP001234"
                  value={credentials.emailOrStaffId}
                  onChange={(e) =>
                    setCredentials({ ...credentials, emailOrStaffId: e.target.value })
                  }
                  className="pl-11 h-12 border-2 border-gray-300 focus:border-blue-600 transition-colors"
                  required
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <Label htmlFor="password" className="text-gray-700 mb-2 block">
                Password
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={credentials.password}
                  onChange={(e) =>
                    setCredentials({ ...credentials, password: e.target.value })
                  }
                  className="pl-11 pr-11 h-12 border-2 border-gray-300 focus:border-blue-600 transition-colors"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            {/* Sign In Button */}
            <Button
              type="submit"
              className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white transition-all duration-200 shadow-md hover:shadow-lg"
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Signing In...
                </span>
              ) : (
                "Sign In"
              )}
            </Button>

            {/* Forgot Password Link */}
            <div className="text-center pt-2">
              <button
                type="button"
                className="text-sm text-gray-600 hover:text-blue-600 transition-colors underline-offset-2 hover:underline"
              >
                Forgot password?
              </button>
            </div>
          </form>

          {/* Security Notice */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <div className="flex items-start gap-2">
              <Lock className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-gray-500">
                This portal is for authorized Guyana Post Office staff only. All access is monitored and logged.
              </p>
            </div>
          </div>
        </Card>

        {/* Help Text */}
        <p className="text-center text-sm text-gray-600 mt-6">
          Need help accessing your account?{" "}
          <a href="#" className="text-blue-600 hover:text-blue-700 hover:underline transition-colors">
            Contact IT Support
          </a>
        </p>
      </div>
    </div>
  );
}