# Archived – Customer UI

**Date Archived:** January 3, 2026  
**Status:** Deprioritized and excluded from main application

## Overview

This directory contains all customer-facing user interface components that have been deprioritized as part of the system redesign. The Guyana Post Office Last-Mile Delivery Tracking System now prioritizes the **Staff/Admin Portal** as the primary interface.

## Archived Components

All customer-facing pages have been consolidated into `/archived/CustomerUI.tsx`:

### 1. **Hero Component** (Customer Home Page)
- Package tracking search interface
- Real-time tracking feature highlights
- Service features overview

### 2. **Header Component** (Customer Navigation)
- Main navigation menu
- Staff Portal access button
- Logo and branding

### 3. **Footer Component** (Customer Footer)
- Quick links
- Contact information
- Business hours
- Social links

### 4. **TrackingResult Component** (Public Package Tracking)
- Public-facing package tracking interface
- Delivery timeline visualization
- Package status display

### 5. **DeliveryPreference Component** (Delivery Options)
- Home delivery options
- Post office pickup selection
- Delivery instructions

### 6. **Services Component** (Services Page)
- Standard delivery information
- Express delivery options
- Track & trace features

### 7. **Locations Component** (Branch Locations)
- Branch listing with addresses
- Contact information per branch
- Operating hours

### 8. **Contact Component** (Contact Page)
- Contact form
- Customer service information
- Business hours

### 9. **FAQs Component** (Frequently Asked Questions)
- Common questions about delivery services
- Tracking instructions
- Policy information

## Reason for Archival

The system has been redesigned to prioritize internal operations and staff workflows over customer-facing features. The Staff/Admin Portal now serves as the main interface, providing:

- Comprehensive package management
- Delivery tracking and updates
- Staff administration
- Branch management
- Analytics and reporting
- Professional shipping label generation

## Usage Status

- ❌ **Excluded from main application** (`/App.tsx`)
- ❌ **Excluded from prototyping workflows**
- ❌ **Excluded from export processes**
- ✅ **Available for reference** (in `/archived/CustomerUI.tsx`)
- ✅ **Preserved for potential future use**

## Accessing Archived Code

To view or reference the archived customer UI components:

```typescript
// All components are available in:
import { 
  Hero,
  Header,
  Footer,
  TrackingResult,
  DeliveryPreference,
  Services,
  Locations,
  Contact,
  FAQs,
  CustomerUIDemo
} from './archived/CustomerUI';
```

## Active System

The current active system focuses on:

**Staff/Admin Portal** (Primary Interface)
- Dashboard with key metrics
- Package management with filters and search
- Package details with timeline tracking
- Add/edit package functionality
- Staff management and administration
- Branch management
- Monthly reports and analytics
- Settings and configuration

All staff-related functionality remains **active and unmodified** in:
- `/components/StaffLogin.tsx`
- `/components/StaffDashboard.tsx`
- `/components/staff/*` (all staff pages)

## Design System

The archived customer UI uses the same design system as the staff portal:

- **Colors:** Blue, white, and red theme (Guyana Post Office branding)
- **Components:** shadcn/ui component library
- **Styling:** Tailwind CSS
- **Icons:** Lucide React

## Notes

- Customer-facing components are **fully functional** but not connected to the main application flow
- All components are preserved with complete functionality for potential future restoration
- The Staff/Admin Portal is now the default landing experience
- No modifications were made to any staff-related pages during archival

---

**For questions or to restore customer-facing features, refer to this archived code as the source of truth.**
