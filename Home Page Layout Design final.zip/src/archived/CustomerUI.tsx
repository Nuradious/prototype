/**
 * ARCHIVED - Customer UI Components
 * 
 * This file contains all customer-facing pages that have been deprioritized.
 * These components are excluded from the main application flow and prototyping.
 * 
 * The Staff/Admin Portal is now the primary interface for the Guyana Post Office
 * Last-Mile Delivery Tracking System.
 * 
 * Archived Components:
 * - Hero (Home page with tracking search)
 * - Header (Customer navigation)
 * - Footer (Customer footer)
 * - TrackingResult (Public tracking results)
 * - DeliveryPreference (Delivery options for customers)
 * - Contact (Customer contact page)
 * - Services (Customer services page)
 * - Locations (Branch locations for customers)
 * - FAQs (Frequently asked questions)
 * 
 * Date Archived: January 3, 2026
 * Reason: System redesigned to prioritize internal staff portal as main experience
 */

import { useState } from "react";
import { Search, MapPin, Clock, Shield, Phone, Mail, MapPinIcon, Package, Truck, CheckCircle, Home } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Badge } from "../components/ui/badge";
import { Separator } from "../components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../components/ui/accordion";

// ============================================================================
// HERO COMPONENT (Customer Home Page)
// ============================================================================

interface HeroProps {
  onTrack: () => void;
}

export function Hero({ onTrack }: HeroProps) {
  const [trackingNumber, setTrackingNumber] = useState("");

  const handleTrack = () => {
    if (trackingNumber.trim()) {
      onTrack();
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleTrack();
    }
  };

  return (
    <div className="relative">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-sm">Real-time package tracking</span>
            </div>
            
            <h2 className="mb-6">
              Track Your Package in Real-Time
            </h2>
            
            <p className="text-blue-100 mb-12 text-lg">
              Enter your tracking number below to get instant updates on your delivery status
            </p>

            {/* Tracking Input */}
            <div className="bg-white rounded-xl shadow-2xl p-6 md:p-8">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <Input
                    type="text"
                    placeholder="Enter tracking number (e.g., GY123456789)"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="h-14 text-gray-900 border-2 border-gray-200 focus:border-blue-500"
                  />
                </div>
                <Button
                  onClick={handleTrack}
                  className="h-14 px-8 bg-red-600 hover:bg-red-700 text-white transition-all duration-200"
                  size="lg"
                >
                  <Search className="w-5 h-5 mr-2" />
                  Track Package
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="mb-2 text-gray-900">Real-Time Location</h3>
              <p className="text-gray-600">
                Track your package's exact location throughout Guyana
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="mb-2 text-gray-900">Estimated Delivery</h3>
              <p className="text-gray-600">
                Get accurate delivery time estimates and notifications
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="mb-2 text-gray-900">Secure Delivery</h3>
              <p className="text-gray-600">
                Your packages are safe with our trusted delivery network
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// HEADER COMPONENT (Customer Navigation)
// ============================================================================

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: "home" | "services" | "locations" | "faqs" | "contact" | "staff-login") => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => onNavigate("home")}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-red-600 rounded-lg flex items-center justify-center">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col items-start">
              <span className="text-sm text-gray-500">Guyana Post Office</span>
            </div>
          </button>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <button
              onClick={() => onNavigate("services")}
              className={`text-sm transition-colors ${
                currentPage === "services"
                  ? "text-blue-600"
                  : "text-gray-600 hover:text-blue-600"
              }`}
            >
              Services
            </button>
            <button
              onClick={() => onNavigate("locations")}
              className={`text-sm transition-colors ${
                currentPage === "locations"
                  ? "text-blue-600"
                  : "text-gray-600 hover:text-blue-600"
              }`}
            >
              Locations
            </button>
            <button
              onClick={() => onNavigate("faqs")}
              className={`text-sm transition-colors ${
                currentPage === "faqs"
                  ? "text-blue-600"
                  : "text-gray-600 hover:text-blue-600"
              }`}
            >
              FAQs
            </button>
            <button
              onClick={() => onNavigate("contact")}
              className={`text-sm transition-colors ${
                currentPage === "contact"
                  ? "text-blue-600"
                  : "text-gray-600 hover:text-blue-600"
              }`}
            >
              Contact
            </button>
          </nav>

          {/* Staff Portal Button */}
          <Button
            onClick={() => onNavigate("staff-login")}
            variant="outline"
            className="border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            Staff Portal
          </Button>
        </div>
      </div>
    </header>
  );
}

// ============================================================================
// FOOTER COMPONENT (Customer Footer)
// ============================================================================

interface FooterProps {
  onNavigate: (page: "home" | "services" | "locations" | "faqs" | "contact") => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-gray-900 text-white mt-auto">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="mb-4">Guyana Post Office</h3>
            <p className="text-gray-400 text-sm">
              Delivering excellence across Guyana with our modern last-mile delivery tracking system.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => onNavigate("services")}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("locations")}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Locations
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("faqs")}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  FAQs
                </button>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="mb-4">Contact Us</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                +592 227 1234
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                info@guyanapost.gy
              </li>
              <li className="flex items-center gap-2">
                <MapPinIcon className="w-4 h-4" />
                Georgetown, Guyana
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div>
            <h4 className="mb-4">Business Hours</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>Monday - Friday: 8AM - 4PM</li>
              <li>Saturday: 8AM - 12PM</li>
              <li>Sunday: Closed</li>
            </ul>
          </div>
        </div>

        <Separator className="my-8 bg-gray-800" />

        <div className="text-center text-sm text-gray-400">
          <p>&copy; 2026 Guyana Post Office. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

// ============================================================================
// TRACKING RESULT COMPONENT (Public Package Tracking)
// ============================================================================

interface TrackingResultProps {
  onBack: () => void;
}

export function TrackingResult({ onBack }: TrackingResultProps) {
  const trackingData = {
    trackingNumber: "GY123456789",
    status: "In Transit",
    estimatedDelivery: "January 5, 2026",
    currentLocation: "Georgetown Distribution Center",
    timeline: [
      {
        status: "Package Received",
        location: "Linden Post Office",
        date: "Jan 2, 2026",
        time: "10:30 AM",
        completed: true,
      },
      {
        status: "In Transit",
        location: "Georgetown Distribution Center",
        date: "Jan 3, 2026",
        time: "2:15 PM",
        completed: true,
      },
      {
        status: "Out for Delivery",
        location: "Georgetown",
        date: "Jan 5, 2026",
        time: "Expected",
        completed: false,
      },
      {
        status: "Delivered",
        location: "Delivery Address",
        date: "Jan 5, 2026",
        time: "Expected",
        completed: false,
      },
    ],
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <Button
          onClick={onBack}
          variant="ghost"
          className="mb-6"
        >
          <Home className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle>Tracking Number: {trackingData.trackingNumber}</CardTitle>
                <CardDescription>Last updated: January 3, 2026 at 2:15 PM</CardDescription>
              </div>
              <Badge className="bg-blue-600">
                {trackingData.status}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {/* Summary */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Estimated Delivery</p>
                  <p className="text-gray-900">{trackingData.estimatedDelivery}</p>
                </div>
                <div className="p-4 bg-gray-100 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Current Location</p>
                  <p className="text-gray-900">{trackingData.currentLocation}</p>
                </div>
              </div>

              <Separator />

              {/* Timeline */}
              <div>
                <h3 className="mb-6 text-gray-900">Tracking Timeline</h3>
                <div className="space-y-4">
                  {trackingData.timeline.map((event, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            event.completed
                              ? "bg-blue-600 text-white"
                              : "bg-gray-200 text-gray-400"
                          }`}
                        >
                          {event.completed ? (
                            <CheckCircle className="w-5 h-5" />
                          ) : (
                            <Clock className="w-5 h-5" />
                          )}
                        </div>
                        {index < trackingData.timeline.length - 1 && (
                          <div
                            className={`w-0.5 h-16 ${
                              event.completed ? "bg-blue-600" : "bg-gray-200"
                            }`}
                          />
                        )}
                      </div>
                      <div className="flex-1 pb-8">
                        <h4 className="text-gray-900">{event.status}</h4>
                        <p className="text-sm text-gray-600">{event.location}</p>
                        <p className="text-sm text-gray-500 mt-1">
                          {event.date} • {event.time}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// ============================================================================
// DELIVERY PREFERENCE COMPONENT (Customer Delivery Options)
// ============================================================================

interface DeliveryPreferenceProps {
  onBack: () => void;
}

export function DeliveryPreference({ onBack }: DeliveryPreferenceProps) {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <Button
          onClick={onBack}
          variant="ghost"
          className="mb-6"
        >
          <Home className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>Delivery Preferences</CardTitle>
            <CardDescription>
              Choose how you'd like to receive your package
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="home" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="home">Home Delivery</TabsTrigger>
                <TabsTrigger value="pickup">Post Office Pickup</TabsTrigger>
              </TabsList>
              <TabsContent value="home" className="space-y-4">
                <p className="text-gray-600">
                  We'll deliver your package directly to your doorstep during business hours.
                </p>
                <div className="space-y-2">
                  <h4 className="text-gray-900">Delivery Instructions</h4>
                  <Input placeholder="e.g., Leave at front door, Ring bell twice" />
                </div>
              </TabsContent>
              <TabsContent value="pickup" className="space-y-4">
                <p className="text-gray-600">
                  Pick up your package at your nearest post office at your convenience.
                </p>
                <div className="space-y-2">
                  <h4 className="text-gray-900">Select Location</h4>
                  <select className="w-full p-2 border rounded-md">
                    <option>Georgetown Central Post Office</option>
                    <option>Linden Post Office</option>
                    <option>New Amsterdam Post Office</option>
                  </select>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// ============================================================================
// SERVICES COMPONENT (Customer Services Page)
// ============================================================================

export function Services() {
  return (
    <div className="py-16">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Our Services</h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Comprehensive postal and delivery services across Guyana
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <Truck className="w-12 h-12 text-blue-600 mb-4" />
              <CardTitle>Standard Delivery</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Regular delivery service within 3-5 business days across Guyana
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Package className="w-12 h-12 text-red-600 mb-4" />
              <CardTitle>Express Delivery</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Priority delivery within 1-2 business days for urgent packages
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <MapPin className="w-12 h-12 text-blue-600 mb-4" />
              <CardTitle>Track & Trace</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Real-time tracking of your packages from pickup to delivery
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// LOCATIONS COMPONENT (Branch Locations Page)
// ============================================================================

export function Locations() {
  const locations = [
    {
      name: "Georgetown Central Post Office",
      address: "Main Street, Georgetown",
      phone: "+592 227 1234",
      hours: "Mon-Fri: 8AM-4PM, Sat: 8AM-12PM",
    },
    {
      name: "Linden Post Office",
      address: "Central Linden",
      phone: "+592 444 5678",
      hours: "Mon-Fri: 8AM-4PM",
    },
    {
      name: "New Amsterdam Post Office",
      address: "New Amsterdam, Berbice",
      phone: "+592 333 9876",
      hours: "Mon-Fri: 8AM-4PM",
    },
  ];

  return (
    <div className="py-16">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Our Locations</h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Visit any of our branches across Guyana
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {locations.map((location, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle>{location.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-start gap-2">
                  <MapPinIcon className="w-4 h-4 text-gray-500 mt-1 flex-shrink-0" />
                  <p className="text-sm text-gray-600">{location.address}</p>
                </div>
                <div className="flex items-start gap-2">
                  <Phone className="w-4 h-4 text-gray-500 mt-1 flex-shrink-0" />
                  <p className="text-sm text-gray-600">{location.phone}</p>
                </div>
                <div className="flex items-start gap-2">
                  <Clock className="w-4 h-4 text-gray-500 mt-1 flex-shrink-0" />
                  <p className="text-sm text-gray-600">{location.hours}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// CONTACT COMPONENT (Contact Page)
// ============================================================================

export function Contact() {
  return (
    <div className="py-16">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Contact Us</h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Get in touch with our customer service team
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Send us a Message</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm text-gray-600">Name</label>
                <Input placeholder="Your name" />
              </div>
              <div>
                <label className="text-sm text-gray-600">Email</label>
                <Input type="email" placeholder="your@email.com" />
              </div>
              <div>
                <label className="text-sm text-gray-600">Message</label>
                <textarea
                  className="w-full p-2 border rounded-md min-h-[120px]"
                  placeholder="How can we help you?"
                />
              </div>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                Send Message
              </Button>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="text-sm text-gray-600">Phone</p>
                    <p className="text-gray-900">+592 227 1234</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="text-sm text-gray-600">Email</p>
                    <p className="text-gray-900">info@guyanapost.gy</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPinIcon className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="text-sm text-gray-600">Address</p>
                    <p className="text-gray-900">
                      Main Street, Georgetown<br />
                      Guyana, South America
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Business Hours</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Monday - Friday</span>
                  <span className="text-gray-900">8:00 AM - 4:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Saturday</span>
                  <span className="text-gray-900">8:00 AM - 12:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Sunday</span>
                  <span className="text-gray-900">Closed</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// FAQs COMPONENT (Frequently Asked Questions)
// ============================================================================

export function FAQs() {
  return (
    <div className="py-16">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Frequently Asked Questions</h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Find answers to common questions about our delivery services
          </p>
        </div>

        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-1">
            <AccordionTrigger>How do I track my package?</AccordionTrigger>
            <AccordionContent>
              Enter your tracking number on our home page to view real-time updates
              on your package's location and estimated delivery time.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-2">
            <AccordionTrigger>What are the delivery times?</AccordionTrigger>
            <AccordionContent>
              Standard delivery takes 3-5 business days, while express delivery
              is available within 1-2 business days for urgent packages.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-3">
            <AccordionTrigger>Can I change my delivery address?</AccordionTrigger>
            <AccordionContent>
              Yes, you can update your delivery preferences and address by contacting
              our customer service team before the package is out for delivery.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-4">
            <AccordionTrigger>What if I miss my delivery?</AccordionTrigger>
            <AccordionContent>
              If you miss a delivery, our driver will leave a notice with instructions
              for scheduling a redelivery or picking up your package at the nearest
              post office.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-5">
            <AccordionTrigger>How do I file a complaint or inquiry?</AccordionTrigger>
            <AccordionContent>
              Contact our customer service team via phone at +592 227 1234 or email
              at info@guyanapost.gy. You can also visit our Contact page to send
              us a message directly.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
}

// ============================================================================
// DEMO APP - Customer UI Showcase (For Reference Only)
// ============================================================================

export function CustomerUIDemo() {
  const [currentPage, setCurrentPage] = useState<
    "home" | "tracking" | "delivery" | "services" | "locations" | "faqs" | "contact"
  >("home");

  const renderPage = () => {
    switch (currentPage) {
      case "tracking":
        return <TrackingResult onBack={() => setCurrentPage("home")} />;
      case "delivery":
        return <DeliveryPreference onBack={() => setCurrentPage("home")} />;
      case "contact":
        return <Contact />;
      case "services":
        return <Services />;
      case "locations":
        return <Locations />;
      case "faqs":
        return <FAQs />;
      default:
        return <Hero onTrack={() => setCurrentPage("tracking")} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header
        currentPage={currentPage}
        onNavigate={(page) => setCurrentPage(page as any)}
      />
      <main className="flex-1">{renderPage()}</main>
      <Footer onNavigate={setCurrentPage} />
    </div>
  );
}
