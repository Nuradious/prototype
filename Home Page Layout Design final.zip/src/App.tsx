import { useState } from "react";
import { StaffLogin } from "./components/StaffLogin";
import { StaffDashboard } from "./components/StaffDashboard";

/**
 * Guyana Post Office - Last-Mile Delivery Tracking System
 * Staff/Admin Portal (Primary Interface)
 *
 * This is the main application entry point, prioritizing the internal staff portal.
 * All customer-facing pages have been archived to /archived/CustomerUI.tsx
 *
 * Main Features:
 * - Staff authentication and login
 * - Comprehensive package management
 * - Delivery tracking and status updates
 * - Staff administration
 * - Branch management
 * - Monthly reports and analytics
 * - Professional shipping label generation
 */

export default function App() {
  const [currentPage, setCurrentPage] = useState<
    "staff-login" | "staff-dashboard"
  >("staff-dashboard");

  // Staff Login page
  if (currentPage === "staff-login") {
    return (
      <StaffLogin
        onBack={() => {
          // No customer interface available - stay on login
          console.log("Customer interface has been archived");
        }}
        onLoginSuccess={() => setCurrentPage("staff-dashboard")}
      />
    );
  }

  // Staff Dashboard (Main Interface)
  return (
    <StaffDashboard
      onLogout={() => setCurrentPage("staff-login")}
    />
  );
}